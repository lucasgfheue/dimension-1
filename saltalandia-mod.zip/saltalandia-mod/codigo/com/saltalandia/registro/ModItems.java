package com.saltalandia.registro;

import com.saltalandia.Saltalandia;
import com.saltalandia.objetos.EspadaHuesuda;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Todos los items de Saltalandia (bloques, materiales, comidas y huevos). */
public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Saltalandia.MODID);

    // ------------------------------------------------------------------ bloques
    public static final DeferredItem<BlockItem> CESPED_SALTARIN = bloque("cesped_saltarin", ModBloques.CESPED_SALTARIN);
    public static final DeferredItem<BlockItem> TIERRA_DULCE = bloque("tierra_dulce", ModBloques.TIERRA_DULCE);
    public static final DeferredItem<BlockItem> PIEDRA_PASTEL = bloque("piedra_pastel", ModBloques.PIEDRA_PASTEL);
    public static final DeferredItem<BlockItem> LADRILLOS_PASTEL = bloque("ladrillos_pastel", ModBloques.LADRILLOS_PASTEL);
    public static final DeferredItem<BlockItem> MENA_GEMA = bloque("mena_gema", ModBloques.MENA_GEMA);
    public static final DeferredItem<BlockItem> MENA_AZUCAR = bloque("mena_azucar", ModBloques.MENA_AZUCAR);
    public static final DeferredItem<BlockItem> MENA_AMBAR = bloque("mena_ambar", ModBloques.MENA_AMBAR);
    public static final DeferredItem<BlockItem> MENA_LUNARITA = bloque("mena_lunarita", ModBloques.MENA_LUNARITA);
    public static final DeferredItem<BlockItem> BLOQUE_REBOTE = bloque("bloque_rebote", ModBloques.BLOQUE_REBOTE);
    public static final DeferredItem<BlockItem> NUBE_SOLIDA = bloque("nube_solida", ModBloques.NUBE_SOLIDA);
    public static final DeferredItem<BlockItem> PORTAL_SALTARIN = bloque("portal_saltarin", ModBloques.PORTAL_SALTARIN);
    public static final DeferredItem<BlockItem> LAMPARA_LUNARITA = bloque("lampara_lunarita", ModBloques.LAMPARA_LUNARITA);
    public static final DeferredItem<BlockItem> TRONCO_POMPON = bloque("tronco_pompon", ModBloques.TRONCO_POMPON);
    public static final DeferredItem<BlockItem> TABLONES_POMPON = bloque("tablones_pompon", ModBloques.TABLONES_POMPON);
    public static final DeferredItem<BlockItem> TRONCO_CANELA = bloque("tronco_canela", ModBloques.TRONCO_CANELA);
    public static final DeferredItem<BlockItem> TABLONES_CANELA = bloque("tablones_canela", ModBloques.TABLONES_CANELA);
    public static final DeferredItem<BlockItem> HOJAS_POMPON = bloque("hojas_pompon", ModBloques.HOJAS_POMPON);
    public static final DeferredItem<BlockItem> HOJAS_ALGODON = bloque("hojas_algodon", ModBloques.HOJAS_ALGODON);
    public static final DeferredItem<BlockItem> HOJAS_MENTA = bloque("hojas_menta", ModBloques.HOJAS_MENTA);
    public static final DeferredItem<BlockItem> HOJAS_LIMON = bloque("hojas_limon", ModBloques.HOJAS_LIMON);
    public static final DeferredItem<BlockItem> FLOR_CAMPANILLA = bloque("flor_campanilla", ModBloques.FLOR_CAMPANILLA);
    public static final DeferredItem<BlockItem> FLOR_REMOLINO = bloque("flor_remolino", ModBloques.FLOR_REMOLINO);
    public static final DeferredItem<BlockItem> HONGO_LUCERO = bloque("hongo_lucero", ModBloques.HONGO_LUCERO);

    // ------------------------------------------------------------------ minerales y materiales
    public static final DeferredItem<Item> GEMA_SALTARINA = ITEMS.registerSimpleItem("gema_saltarina");
    public static final DeferredItem<Item> AZUCAR_CRISTAL = ITEMS.registerSimpleItem("azucar_cristal");
    public static final DeferredItem<Item> AMBAR_MIEL = ITEMS.registerSimpleItem("ambar_miel");
    public static final DeferredItem<Item> LUNARITA = ITEMS.registerSimpleItem("lunarita");
    public static final DeferredItem<Item> GOMA_AGRIA = ITEMS.registerSimpleItem("goma_agria");

    // ------------------------------------------------------------------ comidas
    /** Super salto y caida lenta. Cae de las Hojas Pompon. */
    public static final DeferredItem<Item> FRUTA_SALTARINA = ITEMS.registerSimpleItem("fruta_saltarina",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.JUMP, 900, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0), 1.0F)
                    .build()));
    /** Te hace correr mas rapido. Cae de las Hojas Limon. */
    public static final DeferredItem<Item> LIMON_BURBUJA = ITEMS.registerSimpleItem("limon_burbuja",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 0), 1.0F)
                    .build()));
    /** Se come rapidisimo y regenera un poco. Cae de las Hojas Algodon. */
    public static final DeferredItem<Item> ALGODON_AZUCAR = ITEMS.registerSimpleItem("algodon_azucar",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).fast().alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F)
                    .build()));
    /** Bayas Menta: se comen o se plantan para que crezca un arbusto. */
    public static final DeferredItem<ItemNameBlockItem> BAYAS_MENTA = ITEMS.register("bayas_menta",
            () -> new ItemNameBlockItem(ModBloques.ARBUSTO_BAYAS.get(),
                    new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.2F).fast().build())));
    public static final DeferredItem<Item> CARAMELO_MIEL = ITEMS.registerSimpleItem("caramelo_miel",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.5F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 1200, 0), 1.0F)
                    .build()));
    public static final DeferredItem<Item> PASTEL_BAYAS = ITEMS.registerSimpleItem("pastel_bayas",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> BROCHETA_FRUTAS = ITEMS.registerSimpleItem("brocheta_frutas",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(10).saturationModifier(0.8F)
                    .effect(() -> new MobEffectInstance(MobEffects.JUMP, 600, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 0), 1.0F)
                    .build()));

    // ------------------------------------------------------------------ armas
    /** La espada del Huesudo: pega como una de hierro y deja lento al enemigo. */
    public static final DeferredItem<EspadaHuesuda> ESPADA_HUESUDA = ITEMS.register("espada_huesuda",
            () -> new EspadaHuesuda(Tiers.IRON, new Item.Properties().attributes(SwordItem.createAttributes(Tiers.IRON, 3, -2.4F))));

    // ------------------------------------------------------------------ huevos de los personajes
    public static final DeferredItem<DeferredSpawnEggItem> HUEVO_BRINCO = ITEMS.register("brinco_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntidades.BRINCO, 0x708935, 0xEEB263, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> HUEVO_GRUNON = ITEMS.register("grunon_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntidades.GRUNON, 0x4F6B55, 0xC42C1E, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> HUEVO_HUESUDO = ITEMS.register("huesudo_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntidades.HUESUDO, 0xDCD8C8, 0x424240, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> HUEVO_BRINCO_FANTASMA = ITEMS.register("brinco_fantasma_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntidades.BRINCO_FANTASMA, 0xD6F2FF, 0x6FA8DC, new Item.Properties()));

    private ModItems() {
    }

    private static DeferredItem<BlockItem> bloque(String nombre, net.neoforged.neoforge.registries.DeferredBlock<?> bloque) {
        return ITEMS.registerSimpleBlockItem(nombre, bloque);
    }
}
