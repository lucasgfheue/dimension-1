package com.saltalandia.registro;

import com.saltalandia.Saltalandia;
import com.saltalandia.entidades.Brinco;
import com.saltalandia.entidades.BrincoFantasma;
import com.saltalandia.entidades.Grunon;
import com.saltalandia.entidades.Huesudo;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Los personajes de Saltalandia. */
public final class ModEntidades {
    public static final DeferredRegister<EntityType<?>> ENTIDADES = DeferredRegister.create(Registries.ENTITY_TYPE, Saltalandia.MODID);

    /** Bueno: jugador con la skin de tortuga. Vive en los Pueblos Brinco y regala comida. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<Brinco>> BRINCO = ENTIDADES.register("brinco",
            () -> EntityType.Builder.of(Brinco::new, MobCategory.CREATURE).sized(0.5F, 1.5F).clientTrackingRange(10)
                    .build(Saltalandia.MODID + ":brinco"));

    /** Malo: version zombi de la tortuga. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<Grunon>> GRUNON = ENTIDADES.register("grunon",
            () -> EntityType.Builder.of(Grunon::new, MobCategory.MONSTER).sized(0.5F, 1.5F).clientTrackingRange(8)
                    .build(Saltalandia.MODID + ":grunon"));

    /** Malo: version esqueleto de la tortuga, con arco. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<Huesudo>> HUESUDO = ENTIDADES.register("huesudo",
            () -> EntityType.Builder.of(Huesudo::new, MobCategory.MONSTER).sized(0.5F, 1.5F).clientTrackingRange(8)
                    .build(Saltalandia.MODID + ":huesudo"));

    /** Malo (raro): version fantasma del Brinco, vuela y atraviesa bloques. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<BrincoFantasma>> BRINCO_FANTASMA = ENTIDADES.register("brinco_fantasma",
            () -> EntityType.Builder.of(BrincoFantasma::new, MobCategory.MONSTER).sized(0.5F, 1.5F).clientTrackingRange(8)
                    .build(Saltalandia.MODID + ":brinco_fantasma"));

    private ModEntidades() {
    }
}
