package com.saltalandia.registro;

import com.saltalandia.Saltalandia;
import com.saltalandia.entidades.Brinco;
import com.saltalandia.entidades.BrincoFantasma;
import com.saltalandia.entidades.GallinaConfite;
import com.saltalandia.entidades.Grunon;
import com.saltalandia.entidades.Huesudo;
import com.saltalandia.entidades.LlamaAlgodon;
import com.saltalandia.entidades.LoboMenta;
import com.saltalandia.entidades.ToroCaramelo;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Los personajes de Saltalandia. */
public final class ModEntidades {
    public static final DeferredRegister<EntityType<?>> ENTIDADES = DeferredRegister.create(Registries.ENTITY_TYPE, Saltalandia.MODID);

    /** Bueno: jugador con la skin de tortuga. Vive en los Pueblos Brinco y regala comida. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<Brinco>> BRINCO = ENTIDADES.register("brinco",
            () -> EntityType.Builder.of(Brinco::new, MobCategory.CREATURE).sized(0.5F, 1.5F).clientTrackingRange(10)
                    .build(Saltalandia.MODID + ":brinco"));

    /** Malo: version zombi de la tortuga. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<Grunon>> GRUNON = ENTIDADES.register("grunon",
            () -> EntityType.Builder.of(Grunon::new, MobCategory.MONSTER).sized(0.5F, 1.5F).clientTrackingRange(8)
                    .build(Saltalandia.MODID + ":grunon"));

    /** Malo: version esqueleto de la tortuga, con arco. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<Huesudo>> HUESUDO = ENTIDADES.register("huesudo",
            () -> EntityType.Builder.of(Huesudo::new, MobCategory.MONSTER).sized(0.5F, 1.5F).clientTrackingRange(8)
                    .build(Saltalandia.MODID + ":huesudo"));

    /** Malo (raro): version fantasma del Brinco, vuela y atraviesa bloques. Mide 1,5 bloques. */
    public static final DeferredHolder<EntityType<?>, EntityType<BrincoFantasma>> BRINCO_FANTASMA = ENTIDADES.register("brinco_fantasma",
            () -> EntityType.Builder.of(BrincoFantasma::new, MobCategory.MONSTER).sized(0.5F, 1.5F).clientTrackingRange(8)
                    .build(Saltalandia.MODID + ":brinco_fantasma"));

    // ------------------------------------------------------------------ animales (mismo tamano que los de Minecraft)
    /** Toro Caramelo (praderas). */
    public static final DeferredHolder<EntityType<?>, EntityType<ToroCaramelo>> TORO_CARAMELO = ENTIDADES.register("toro_caramelo",
            () -> EntityType.Builder.of(ToroCaramelo::new, MobCategory.CREATURE).sized(0.9F, 1.4F).eyeHeight(1.3F).passengerAttachments(1.36875F)
                    .clientTrackingRange(10).build(Saltalandia.MODID + ":toro_caramelo"));

    /** Llama Algodon (jardin). */
    public static final DeferredHolder<EntityType<?>, EntityType<LlamaAlgodon>> LLAMA_ALGODON = ENTIDADES.register("llama_algodon",
            () -> EntityType.Builder.of(LlamaAlgodon::new, MobCategory.CREATURE).sized(0.9F, 1.87F).eyeHeight(1.7765F)
                    .passengerAttachments(new Vec3(0.0D, 1.37D, -0.3D)).clientTrackingRange(10).build(Saltalandia.MODID + ":llama_algodon"));

    /** Lobo Menta (bosque). */
    public static final DeferredHolder<EntityType<?>, EntityType<LoboMenta>> LOBO_MENTA = ENTIDADES.register("lobo_menta",
            () -> EntityType.Builder.of(LoboMenta::new, MobCategory.CREATURE).sized(0.6F, 0.85F).eyeHeight(0.68F)
                    .passengerAttachments(new Vec3(0.0D, 0.81875D, -0.0625D)).clientTrackingRange(10).build(Saltalandia.MODID + ":lobo_menta"));

    /** Gallina Confite (praderas y jardin). */
    public static final DeferredHolder<EntityType<?>, EntityType<GallinaConfite>> GALLINA_CONFITE = ENTIDADES.register("gallina_confite",
            () -> EntityType.Builder.of(GallinaConfite::new, MobCategory.CREATURE).sized(0.4F, 0.7F).eyeHeight(0.644F)
                    .clientTrackingRange(10).build(Saltalandia.MODID + ":gallina_confite"));

    private ModEntidades() {
    }
}
