package com.saltalandia.registro;

import com.saltalandia.Saltalandia;
import com.saltalandia.bloques.BloqueBlando;
import com.saltalandia.bloques.BloqueRebote;
import com.saltalandia.bloques.PortalSaltarin;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Todos los bloques de Saltalandia. */
public final class ModBloques {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(Saltalandia.MODID);

    // ------------------------------------------------------------------ suelo

    /** Pasto que amortigua las caidas (solo recibes el 20% del dano). */
    public static final DeferredBlock<BloqueBlando> CESPED_SALTARIN = BLOCKS.registerBlock("cesped_saltarin",
            props -> new BloqueBlando(0.2F, props),
            BlockBehaviour.Properties.of().mapColor(MapColor.GRASS).strength(0.6F).sound(SoundType.GRASS));

    public static final DeferredBlock<Block> TIERRA_DULCE = BLOCKS.registerSimpleBlock("tierra_dulce",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE).strength(0.5F).sound(SoundType.GRAVEL));

    public static final DeferredBlock<Block> PIEDRA_PASTEL = BLOCKS.registerSimpleBlock("piedra_pastel", piedra(1.5F));

    public static final DeferredBlock<Block> LADRILLOS_PASTEL = BLOCKS.registerSimpleBlock("ladrillos_pastel", piedra(2.0F));

    // ------------------------------------------------------------------ minerales

    public static final DeferredBlock<DropExperienceBlock> MENA_GEMA = mena("mena_gema", 2, 5, 3);
    public static final DeferredBlock<DropExperienceBlock> MENA_AZUCAR = mena("mena_azucar", 0, 2, 0);
    public static final DeferredBlock<DropExperienceBlock> MENA_AMBAR = mena("mena_ambar", 1, 3, 4);
    public static final DeferredBlock<DropExperienceBlock> MENA_LUNARITA = mena("mena_lunarita", 3, 7, 9);

    // ------------------------------------------------------------------ especiales

    /** Trampolin: te lanza por el aire al pisarlo (agachate para no rebotar). */
    public static final DeferredBlock<BloqueRebote> BLOQUE_REBOTE = BLOCKS.registerBlock("bloque_rebote",
            BloqueRebote::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_MAGENTA).strength(0.8F).sound(SoundType.SLIME_BLOCK).noOcclusion());

    /** Nube donde se puede caminar: anula todo el dano por caida. */
    public static final DeferredBlock<BloqueBlando> NUBE_SOLIDA = BLOCKS.registerBlock("nube_solida",
            props -> new BloqueBlando(0.0F, props),
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.3F).sound(SoundType.WOOL));

    /** Clic derecho para viajar entre el mundo normal y Saltalandia. */
    public static final DeferredBlock<PortalSaltarin> PORTAL_SALTARIN = BLOCKS.registerBlock("portal_saltarin",
            PortalSaltarin::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(2.0F, 6.0F)
                    .lightLevel(estado -> 12).sound(SoundType.GLASS));

    public static final DeferredBlock<Block> LAMPARA_LUNARITA = BLOCKS.registerSimpleBlock("lampara_lunarita",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).strength(0.5F)
                    .lightLevel(estado -> 15).sound(SoundType.GLASS));

    // ------------------------------------------------------------------ arboles

    public static final DeferredBlock<RotatedPillarBlock> TRONCO_POMPON = BLOCKS.registerBlock("tronco_pompon",
            RotatedPillarBlock::new, madera(MapColor.COLOR_PINK, 2.0F));
    public static final DeferredBlock<Block> TABLONES_POMPON = BLOCKS.registerSimpleBlock("tablones_pompon",
            madera(MapColor.COLOR_PINK, 2.0F));
    public static final DeferredBlock<RotatedPillarBlock> TRONCO_CANELA = BLOCKS.registerBlock("tronco_canela",
            RotatedPillarBlock::new, madera(MapColor.COLOR_BROWN, 2.0F));
    public static final DeferredBlock<Block> TABLONES_CANELA = BLOCKS.registerSimpleBlock("tablones_canela",
            madera(MapColor.COLOR_BROWN, 2.0F));

    public static final DeferredBlock<LeavesBlock> HOJAS_POMPON = hojas("hojas_pompon", MapColor.COLOR_CYAN);
    public static final DeferredBlock<LeavesBlock> HOJAS_ALGODON = hojas("hojas_algodon", MapColor.COLOR_PINK);
    public static final DeferredBlock<LeavesBlock> HOJAS_MENTA = hojas("hojas_menta", MapColor.COLOR_LIGHT_GREEN);
    public static final DeferredBlock<LeavesBlock> HOJAS_LIMON = hojas("hojas_limon", MapColor.COLOR_YELLOW);

    // ------------------------------------------------------------------ plantas

    public static final DeferredBlock<FlowerBlock> FLOR_CAMPANILLA = BLOCKS.registerBlock("flor_campanilla",
            props -> new FlowerBlock(MobEffects.JUMP, 6.0F, props), planta(0));
    public static final DeferredBlock<FlowerBlock> FLOR_REMOLINO = BLOCKS.registerBlock("flor_remolino",
            props -> new FlowerBlock(MobEffects.MOVEMENT_SPEED, 6.0F, props), planta(0));
    /** Hongo que brilla en la oscuridad. */
    public static final DeferredBlock<FlowerBlock> HONGO_LUCERO = BLOCKS.registerBlock("hongo_lucero",
            props -> new FlowerBlock(MobEffects.NIGHT_VISION, 8.0F, props), planta(10));
    /** Arbusto de Bayas Menta: rompelo para sacar bayas (las bayas se pueden plantar). */
    public static final DeferredBlock<FlowerBlock> ARBUSTO_BAYAS = BLOCKS.registerBlock("arbusto_bayas",
            props -> new FlowerBlock(MobEffects.REGENERATION, 4.0F, props), planta(0));

    private ModBloques() {
    }

    private static BlockBehaviour.Properties piedra(float dureza) {
        return BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).instrument(NoteBlockInstrument.BASEDRUM)
                .requiresCorrectToolForDrops().strength(dureza, 6.0F);
    }

    private static DeferredBlock<DropExperienceBlock> mena(String nombre, int xpMin, int xpMax, int luz) {
        return BLOCKS.registerBlock(nombre,
                props -> new DropExperienceBlock(UniformInt.of(xpMin, xpMax), props),
                BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).instrument(NoteBlockInstrument.BASEDRUM)
                        .requiresCorrectToolForDrops().strength(3.0F, 3.0F).lightLevel(estado -> luz));
    }

    private static BlockBehaviour.Properties madera(MapColor color, float dureza) {
        return BlockBehaviour.Properties.of().mapColor(color).instrument(NoteBlockInstrument.BASS)
                .strength(dureza, 3.0F).sound(SoundType.WOOD).ignitedByLava();
    }

    private static DeferredBlock<LeavesBlock> hojas(String nombre, MapColor color) {
        return BLOCKS.registerBlock(nombre, LeavesBlock::new,
                BlockBehaviour.Properties.of().mapColor(color).strength(0.2F).randomTicks()
                        .sound(SoundType.GRASS).noOcclusion()
                        .isValidSpawn((estado, nivel, pos, tipo) -> tipo == EntityType.OCELOT || tipo == EntityType.PARROT)
                        .isSuffocating((estado, nivel, pos) -> false)
                        .isViewBlocking((estado, nivel, pos) -> false)
                        .ignitedByLava().pushReaction(PushReaction.DESTROY)
                        .isRedstoneConductor((estado, nivel, pos) -> false));
    }

    private static BlockBehaviour.Properties planta(int luz) {
        return BlockBehaviour.Properties.of().mapColor(MapColor.PLANT).noCollission().instabreak()
                .sound(SoundType.GRASS).offsetType(BlockBehaviour.OffsetType.XZ)
                .lightLevel(estado -> luz).pushReaction(PushReaction.DESTROY);
    }
}
