package com.saltalandia.mundo;

import com.mojang.serialization.Codec;
import com.saltalandia.registro.ModBloques;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Genera nubes solidas flotantes: una elipse plana de 1-2 bloques de grosor.
 */
public class NubeFeature extends Feature<NoneFeatureConfiguration> {

    public NubeFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel nivel = context.level();
        BlockPos origen = context.origin();
        RandomSource random = context.random();
        BlockState nube = ModBloques.NUBE_SOLIDA.get().defaultBlockState();

        int radioX = 3 + random.nextInt(4);
        int radioZ = 3 + random.nextInt(4);
        boolean colocada = false;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (int dx = -radioX; dx <= radioX; dx++) {
            for (int dz = -radioZ; dz <= radioZ; dz++) {
                double d = (dx * dx) / (double) (radioX * radioX) + (dz * dz) / (double) (radioZ * radioZ);
                if (d <= 1.0D + random.nextDouble() * 0.2D) {
                    int grosor = d < 0.4D ? 2 : 1;
                    for (int dy = 0; dy < grosor; dy++) {
                        cursor.setWithOffset(origen, dx, dy, dz);
                        if (nivel.isEmptyBlock(cursor)) {
                            nivel.setBlock(cursor, nube, 2);
                            colocada = true;
                        }
                    }
                }
            }
        }
        return colocada;
    }
}
