package com.saltalandia.entidades;

import com.saltalandia.eventos.EstadoDia;
import com.saltalandia.registro.ModEntidades;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.level.Level;

/**
 * Gallina Confite: gallina blanca de merengue con confites de colores y cresta rosada
 * (vive en las Praderas Saltarinas y el Jardin de Algodon). Pone huevos y se cria con semillas.
 * Desde el dia 5 de Saltalandia ya no pone huevos.
 */
public class GallinaConfite extends Chicken {

    public GallinaConfite(EntityType<? extends GallinaConfite> type, Level level) {
        super(type, level);
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide && EstadoDia.dia(this.level()) >= 5) {
            this.eggTime = Math.max(this.eggTime, 600);
        }
        super.aiStep();
    }

    @Override
    public GallinaConfite getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return ModEntidades.GALLINA_CONFITE.get().create(level);
    }
}
