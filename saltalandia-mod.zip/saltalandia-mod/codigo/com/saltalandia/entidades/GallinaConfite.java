package com.saltalandia.entidades;

import com.saltalandia.registro.ModEntidades;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.level.Level;

/**
 * Gallina Confite: gallina blanca de merengue con confites de colores y cresta rosada
 * (vive en las Praderas Saltarinas y el Jardin de Algodon). Pone huevos y se cria con semillas.
 */
public class GallinaConfite extends Chicken {

    public GallinaConfite(EntityType<? extends GallinaConfite> type, Level level) {
        super(type, level);
    }

    @Override
    public GallinaConfite getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return ModEntidades.GALLINA_CONFITE.get().create(level);
    }
}
