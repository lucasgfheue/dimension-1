package com.saltalandia.entidades;

import com.saltalandia.registro.ModEntidades;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.horse.Llama;
import net.minecraft.world.level.Level;

/**
 * Llama Algodon: llama esponjosa de algodon de azucar rosado (vive en el Jardin de Algodon).
 * Funciona como una llama: se domestica montandola, lleva un cofre, se le pone alfombra y escupe.
 */
public class LlamaAlgodon extends Llama {

    public LlamaAlgodon(EntityType<? extends LlamaAlgodon> type, Level level) {
        super(type, level);
    }

    @Override
    protected Llama makeNewLlama() {
        return ModEntidades.LLAMA_ALGODON.get().create(this.level());
    }
}
