package com.saltalandia.entidades;

import com.saltalandia.registro.ModEntidades;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.level.Level;

/**
 * Lobo Menta: lobo verde menta con manchas de menta oscura (vive en el Bosque Pompon).
 * Funciona como un lobo: se domestica con huesos, te sigue y te defiende.
 */
public class LoboMenta extends Wolf {

    public LoboMenta(EntityType<? extends LoboMenta> type, Level level) {
        super(type, level);
    }

    @Override
    public LoboMenta getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        LoboMenta cria = ModEntidades.LOBO_MENTA.get().create(level);
        if (cria != null && this.isTame()) {
            cria.setOwnerUUID(this.getOwnerUUID());
            cria.setTame(true, true);
        }
        return cria;
    }
}
