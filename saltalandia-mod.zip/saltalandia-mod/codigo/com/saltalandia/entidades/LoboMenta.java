package com.saltalandia.entidades;

import com.saltalandia.eventos.EstadoDia;
import com.saltalandia.registro.ModEntidades;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/**
 * Lobo Menta: lobo verde menta con manchas de menta oscura (vive en el Bosque Pompon).
 * Funciona como un lobo: se domestica con huesos, te sigue y te defiende.
 * Desde el dia 3 de Saltalandia ya no se deja domesticar (se come el hueso y echa humo).
 */
public class LoboMenta extends Wolf {

    public LoboMenta(EntityType<? extends LoboMenta> type, Level level) {
        super(type, level);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack cosa = player.getItemInHand(hand);
        if (!this.isTame() && cosa.is(Items.BONE) && EstadoDia.dia(this.level()) >= 3) {
            if (!this.level().isClientSide) {
                cosa.consume(1, player);
                this.level().broadcastEntityEvent(this, (byte) 6);
                player.displayClientMessage(Component.translatable("mensaje.saltalandia.lobo_no"), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public LoboMenta getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        LoboMenta cria = ModEntidades.LOBO_MENTA.get().create(level);
        if (cria != null && this.isTame()) {
            cria.setOwnerUUID(this.getOwnerUUID());
            cria.setTame(true, true);
        }
        return cria;
    }
}
