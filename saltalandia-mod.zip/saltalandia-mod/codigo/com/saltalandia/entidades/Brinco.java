package com.saltalandia.entidades;

import com.saltalandia.eventos.EstadoDia;
import com.saltalandia.registro.ModItems;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

/**
 * Brinco: el personaje bueno. Tiene forma de jugador con la skin de tortuga y mide 1,5 bloques.
 * Vive solo en los Pueblos Brinco (no aparece suelto por el mundo), huye de los malos y,
 * si le haces clic derecho, te regala comida (una vez cada 5 minutos).
 * <p>
 * Con los dias de Saltalandia cambia: desde el dia 3 ya no regala nada ni huye de los malos; desde el 6
 * a veces se "posee" (se queda quieto y gira la cabeza de forma rara); desde el 8 no se mueve y te mira
 * fijamente; el dia 10 desaparece.
 */
public class Brinco extends PathfinderMob {
    private static final int ESPERA_ENTRE_REGALOS = 6000;
    private static final int RADIO_CASA = 20;
    private static final EntityDataAccessor<Boolean> POSEIDO = SynchedEntityData.defineId(Brinco.class, EntityDataSerializers.BOOLEAN);

    private int esperaRegalo;
    private int poseidoTicks;
    private BlockPos casa;

    public Brinco(EntityType<? extends Brinco> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        super.defineSynchedData(datos);
        datos.define(POSEIDO, false);
    }

    /** En el cliente el modelo lo usa para girar la cabeza como si estuviera poseido. */
    public boolean estaPoseido() {
        return this.entityData.get(POSEIDO);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new QuietoMirandoGoal());
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new HuirDeLosMalosGoal());
        this.goalSelector.addGoal(3, new MoveTowardsRestrictionGoal(this, 1.0D));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return super.mobInteract(player, hand);
        }
        if (this.level() instanceof ServerLevel nivel) {
            if (EstadoDia.dia(nivel) >= 3) {
                player.displayClientMessage(Component.translatable("mensaje.saltalandia.brinco_sin_regalo"), true);
            } else if (this.esperaRegalo <= 0) {
                this.spawnAtLocation(this.regaloAlAzar());
                this.esperaRegalo = ESPERA_ENTRE_REGALOS;
                this.playSound(SoundEvents.ITEM_PICKUP, 1.0F, 1.3F);
                nivel.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.6D, this.getZ(), 5, 0.3D, 0.2D, 0.3D, 0.02D);
                player.displayClientMessage(Component.translatable("mensaje.saltalandia.brinco_regalo"), true);
            } else {
                player.displayClientMessage(Component.translatable("mensaje.saltalandia.brinco_cansado"), true);
            }
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private ItemStack regaloAlAzar() {
        return switch (this.random.nextInt(6)) {
            case 0 -> new ItemStack(ModItems.FRUTA_SALTARINA.get(), 2);
            case 1 -> new ItemStack(ModItems.LIMON_BURBUJA.get(), 2);
            case 2 -> new ItemStack(ModItems.ALGODON_AZUCAR.get(), 3);
            case 3 -> new ItemStack(ModItems.BAYAS_MENTA.get(), 4);
            case 4 -> new ItemStack(ModItems.CARAMELO_MIEL.get(), 1);
            default -> new ItemStack(ModItems.PASTEL_BAYAS.get(), 1);
        };
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            return;
        }
        if (this.esperaRegalo > 0) {
            this.esperaRegalo--;
        }
        int dia = EstadoDia.dia(this.level());
        if (dia >= 10) {
            this.discard();
            return;
        }
        if (this.poseidoTicks > 0) {
            if (--this.poseidoTicks == 0) {
                this.entityData.set(POSEIDO, false);
            }
        } else if (dia >= 6 && this.random.nextInt(dia >= 8 ? 260 : 420) == 0) {
            // se "posee" un rato: se queda quieto, mira al jugador y la cabeza se le retuerce
            this.poseidoTicks = 40 + this.random.nextInt(60);
            this.entityData.set(POSEIDO, true);
            this.playSound(SoundEvents.TURTLE_AMBIENT_LAND, 1.0F, 0.35F);
        } else if (dia < 6 && this.estaPoseido()) {
            this.entityData.set(POSEIDO, false);
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, SpawnGroupData groupData) {
        this.casa = this.blockPosition();
        this.restrictTo(this.casa, RADIO_CASA);
        return super.finalizeSpawn(level, difficulty, spawnType, groupData);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("EsperaRegalo", this.esperaRegalo);
        if (this.casa != null) {
            tag.putLong("Casa", this.casa.asLong());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.esperaRegalo = tag.getInt("EsperaRegalo");
        if (tag.contains("Casa")) {
            this.casa = BlockPos.of(tag.getLong("Casa"));
            this.restrictTo(this.casa, RADIO_CASA);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.TURTLE_AMBIENT_LAND;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.TURTLE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.TURTLE_DEATH;
    }

    /** Hasta el dia 2 huye de los malos; desde el dia 3 ya no. */
    class HuirDeLosMalosGoal extends AvoidEntityGoal<Monster> {
        HuirDeLosMalosGoal() {
            super(Brinco.this, Monster.class, 8.0F, 1.0D, 1.35D);
        }

        @Override
        public boolean canUse() {
            return EstadoDia.dia(Brinco.this.level()) < 3 && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return EstadoDia.dia(Brinco.this.level()) < 3 && super.canContinueToUse();
        }
    }

    /** Desde el dia 8 (o mientras esta poseido) se queda quieto mirando fijo al jugador mas cercano. */
    class QuietoMirandoGoal extends Goal {
        QuietoMirandoGoal() {
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return EstadoDia.dia(Brinco.this.level()) >= 8 || Brinco.this.estaPoseido();
        }

        @Override
        public void start() {
            Brinco.this.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            Brinco.this.getNavigation().stop();
            Player jugador = Brinco.this.level().getNearestPlayer(Brinco.this, 48.0D);
            if (jugador != null) {
                Brinco.this.getLookControl().setLookAt(jugador, 360.0F, 360.0F);
            }
        }
    }
}
