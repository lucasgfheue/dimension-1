package com.saltalandia.entidades;

import com.saltalandia.entidades.ia.AtaqueFuriosoGoal;
import com.saltalandia.entidades.ia.CazarJugadorGoal;
import com.saltalandia.entidades.ia.ConstruirGoal;
import com.saltalandia.entidades.ia.Furia;
import com.saltalandia.entidades.ia.RomperBloquesGoal;
import com.saltalandia.eventos.EstadoDia;
import com.saltalandia.registro.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Huesudo: personaje malo, la version esqueleto de la tortuga (mide 1,5 bloques).
 * Pelea con su Espada Huesuda y cada golpe te deja lento unos segundos.
 * Suelta huesos y, con un 5% de probabilidad, su espada (ver su tabla de botin).
 */
public class Huesudo extends Monster {

    public Huesudo(EntityType<? extends Huesudo> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new RomperBloquesGoal(this));
        this.goalSelector.addGoal(1, new ConstruirGoal(this));
        this.goalSelector.addGoal(2, new AtaqueFuriosoGoal(this, 1.1D));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.1D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new CazarJugadorGoal(this, true, 8));
        this.targetSelector.addGoal(3, new CazarJugadorGoal(this, false, 0));
    }

    /** Dias de Saltalandia: furia desde el dia 6 y el dia 10 desaparece. */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.tickCount % 40 == 0) {
            Furia.actualizar(this);
        }
        if (EstadoDia.dia(this.level()) >= 10) {
            this.discard();
        }
    }

    /** Dia 9: trepa las paredes (como una arana) si el jugador esta mas arriba. */
    @Override
    public boolean onClimbable() {
        if (!this.level().isClientSide && this.horizontalCollision) {
            int dia = EstadoDia.dia(this.level());
            LivingEntity objetivo = this.getTarget();
            if (dia >= 9 && dia < 10 && objetivo != null && objetivo.getY() > this.getY() + 0.5D) {
                return true;
            }
        }
        return super.onClimbable();
    }

    /** Siempre aparece con su Espada Huesuda (y sin armadura). */
    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.ESPADA_HUESUDA.get()));
        // no se suelta como equipo: la suelta su tabla de botin (5%, entera y solo si lo mata un jugador)
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, SpawnGroupData groupData) {
        SpawnGroupData datos = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        this.populateDefaultEquipmentSlots(this.getRandom(), difficulty);
        return datos;
    }

    /** Cada golpe te deja lento (la espada en manos de un personaje no usa hurtEnemy, asi que va aca). */
    @Override
    public boolean doHurtTarget(Entity target) {
        boolean golpeo = super.doHurtTarget(target);
        if (golpeo && target instanceof LivingEntity vivo) {
            vivo.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 0), this);
        }
        return golpeo;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.SKELETON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SKELETON_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.SKELETON_STEP, 0.15F, 1.0F);
    }
}
