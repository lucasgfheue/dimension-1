package com.saltalandia.entidades;

import com.saltalandia.entidades.ia.AtaqueFuriosoGoal;
import com.saltalandia.entidades.ia.CazarJugadorGoal;
import com.saltalandia.entidades.ia.ConstruirGoal;
import com.saltalandia.entidades.ia.Furia;
import com.saltalandia.entidades.ia.RomperBloquesGoal;
import com.saltalandia.eventos.EstadoDia;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Gruñón: personaje malo, la version zombi de la tortuga (mide 1,5 bloques).
 * Camina con los brazos estirados, es lento pero resistente y pega fuerte.
 * Cuida los Fortines Gruñón. Suelta Goma Agria y a veces gemas.
 */
public class Grunon extends Monster {

    public Grunon(EntityType<? extends Grunon> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.ARMOR, 4.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new RomperBloquesGoal(this));
        this.goalSelector.addGoal(1, new ConstruirGoal(this));
        this.goalSelector.addGoal(2, new AtaqueFuriosoGoal(this, 1.0D));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new CazarJugadorGoal(this, true, 8));
        this.targetSelector.addGoal(3, new CazarJugadorGoal(this, false, 0));
    }

    /** Dias de Saltalandia: furia desde el dia 6 y el dia 10 desaparece. */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.tickCount % 40 == 0) {
            Furia.actualizar(this);
        }
        if (EstadoDia.dia(this.level()) >= 10) {
            this.discard();
        }
    }

    /** Dia 9: trepa las paredes (como una arana) si el jugador esta mas arriba. */
    @Override
    public boolean onClimbable() {
        if (!this.level().isClientSide && this.horizontalCollision) {
            int dia = EstadoDia.dia(this.level());
            LivingEntity objetivo = this.getTarget();
            if (dia >= 9 && dia < 10 && objetivo != null && objetivo.getY() > this.getY() + 0.5D) {
                return true;
            }
        }
        return super.onClimbable();
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ZOMBIE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.ZOMBIE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ZOMBIE_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.ZOMBIE_STEP, 0.15F, 1.0F);
    }
}
