package com.saltalandia.entidades;

import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * Brinco Fantasma: personaje malo, la version fantasma del Brinco (mide 1,5 bloques).
 * Flota, atraviesa bloques para atacarte (como el vex) y te ve aunque haya paredes en el medio.
 * Aparece mucho menos que los otros malos.
 */
public class BrincoFantasma extends Monster {

    @SuppressWarnings("this-escape")
    public BrincoFantasma(EntityType<? extends BrincoFantasma> type, Level level) {
        super(type, level);
        this.moveControl = new ControlFantasma(this);
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 12.0D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(4, new AtaqueFantasmaGoal());
        this.goalSelector.addGoal(8, new VagarFantasmaGoal());
        this.goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(10, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // false = no necesita verte: te encuentra aunque haya bloques en el medio
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    /** Atraviesa los bloques: mientras se mueve no choca con nada y no le afecta la gravedad. */
    @Override
    public void tick() {
        this.noPhysics = true;
        super.tick();
        this.noPhysics = false;
        this.setNoGravity(true);
    }

    @Override
    public boolean causeFallDamage(float distancia, float multiplicador, DamageSource fuente) {
        return false;
    }

    /** En Saltalandia siempre es de dia: los malos pueden aparecer con luz. */
    @Override
    public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        return 0.0F;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VEX_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.VEX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VEX_DEATH;
    }

    /** Vuela derecho hacia donde quiere ir, sin esquivar bloques (igual que el vex). */
    static class ControlFantasma extends MoveControl {
        private final BrincoFantasma fantasma;

        ControlFantasma(BrincoFantasma fantasma) {
            super(fantasma);
            this.fantasma = fantasma;
        }

        @Override
        public void tick() {
            if (this.operation != MoveControl.Operation.MOVE_TO) {
                return;
            }
            Vec3 hacia = new Vec3(this.wantedX - this.fantasma.getX(), this.wantedY - this.fantasma.getY(), this.wantedZ - this.fantasma.getZ());
            double distancia = hacia.length();
            if (distancia < this.fantasma.getBoundingBox().getSize()) {
                this.operation = MoveControl.Operation.WAIT;
                this.fantasma.setDeltaMovement(this.fantasma.getDeltaMovement().scale(0.5D));
            } else {
                this.fantasma.setDeltaMovement(this.fantasma.getDeltaMovement().add(hacia.scale(this.speedModifier * 0.05D / distancia)));
                LivingEntity objetivo = this.fantasma.getTarget();
                double dx = objetivo == null ? this.fantasma.getDeltaMovement().x : objetivo.getX() - this.fantasma.getX();
                double dz = objetivo == null ? this.fantasma.getDeltaMovement().z : objetivo.getZ() - this.fantasma.getZ();
                this.fantasma.setYRot(-((float) Mth.atan2(dx, dz)) * (180.0F / (float) Math.PI));
                this.fantasma.yBodyRot = this.fantasma.getYRot();
            }
        }
    }

    /** Se lanza hacia tus ojos atravesando lo que haya en el medio. */
    class AtaqueFantasmaGoal extends Goal {
        AtaqueFantasmaGoal() {
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            LivingEntity objetivo = BrincoFantasma.this.getTarget();
            return objetivo != null && objetivo.isAlive() && !BrincoFantasma.this.getMoveControl().hasWanted()
                    && BrincoFantasma.this.random.nextInt(reducedTickDelay(7)) == 0
                    && BrincoFantasma.this.distanceToSqr(objetivo) > 4.0D;
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity objetivo = BrincoFantasma.this.getTarget();
            return BrincoFantasma.this.getMoveControl().hasWanted() && BrincoFantasma.this.isAggressive()
                    && objetivo != null && objetivo.isAlive();
        }

        @Override
        public void start() {
            LivingEntity objetivo = BrincoFantasma.this.getTarget();
            if (objetivo != null) {
                Vec3 ojos = objetivo.getEyePosition();
                BrincoFantasma.this.moveControl.setWantedPosition(ojos.x, ojos.y, ojos.z, 1.0D);
            }
            BrincoFantasma.this.setAggressive(true);
            BrincoFantasma.this.playSound(SoundEvents.VEX_CHARGE, 1.0F, 1.0F);
        }

        @Override
        public void stop() {
            BrincoFantasma.this.setAggressive(false);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity objetivo = BrincoFantasma.this.getTarget();
            if (objetivo == null) {
                return;
            }
            if (BrincoFantasma.this.getBoundingBox().intersects(objetivo.getBoundingBox())) {
                BrincoFantasma.this.doHurtTarget(objetivo);
                BrincoFantasma.this.setAggressive(false);
            } else if (BrincoFantasma.this.distanceToSqr(objetivo) < 9.0D) {
                Vec3 ojos = objetivo.getEyePosition();
                BrincoFantasma.this.moveControl.setWantedPosition(ojos.x, ojos.y, ojos.z, 1.0D);
            }
        }
    }

    /** Cuando no persigue a nadie, flota despacio un poco por encima del suelo. */
    class VagarFantasmaGoal extends Goal {
        VagarFantasmaGoal() {
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return !BrincoFantasma.this.getMoveControl().hasWanted() && BrincoFantasma.this.random.nextInt(reducedTickDelay(7)) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return false;
        }

        @Override
        public void tick() {
            BlockPos aqui = BrincoFantasma.this.blockPosition();
            int x = aqui.getX() + BrincoFantasma.this.random.nextInt(15) - 7;
            int z = aqui.getZ() + BrincoFantasma.this.random.nextInt(15) - 7;
            int y = BrincoFantasma.this.level().getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) + 1 + BrincoFantasma.this.random.nextInt(3);
            BrincoFantasma.this.moveControl.setWantedPosition(x + 0.5D, y + 0.5D, z + 0.5D, 0.25D);
            if (BrincoFantasma.this.getTarget() == null) {
                BrincoFantasma.this.getLookControl().setLookAt(x + 0.5D, y + 0.5D, z + 0.5D, 180.0F, 20.0F);
            }
        }
    }
}
