package com.saltalandia.entidades;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Brinco Sombra: un Brinco todo negro con los ojos blancos. Aparece desde el dia 5, muy pocas veces,
 * entre los arboles (o arriba de una copa) y se queda quieto espiando al jugador.
 * Si el jugador lo mira o se le acerca, desaparece. No ataca, no hace ruido y no se guarda con el mundo.
 */
public class BrincoSombra extends PathfinderMob {
    /** Cuanto se queda si nadie lo ve (1 minuto). */
    private static final int DURACION = 1200;

    private int vistoHace = -1;

    public BrincoSombra(EntityType<? extends BrincoSombra> type, Level level) {
        super(type, level);
    }

    @Override
    public boolean isSilent() {
        return true;
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D);
    }

    @Override
    protected void registerGoals() {
        // no hace nada: solo mira
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        Player jugador = this.level().getNearestPlayer(this, 128.0D);
        if (jugador == null || this.tickCount > DURACION) {
            this.discard();
            return;
        }
        this.mirarA(jugador);
        if (this.distanceTo(jugador) < 9.0F) {
            this.desaparecer();
            return;
        }
        if (this.vistoHace >= 0) {
            if (++this.vistoHace > 6) {
                this.desaparecer();
            }
        } else if (this.loEstaMirando(jugador)) {
            this.vistoHace = 0;
        }
    }

    /** El jugador lo tiene casi en el centro de la pantalla y nada le tapa la vista. */
    private boolean loEstaMirando(Player jugador) {
        Vec3 vista = jugador.getViewVector(1.0F).normalize();
        Vec3 hacia = new Vec3(this.getX() - jugador.getX(), this.getEyeY() - jugador.getEyeY(), this.getZ() - jugador.getZ());
        double distancia = hacia.length();
        if (distancia < 1.0E-4D) {
            return true;
        }
        return vista.dot(hacia.scale(1.0D / distancia)) > 0.975D && jugador.hasLineOfSight(this);
    }

    private void mirarA(Player jugador) {
        double dx = jugador.getX() - this.getX();
        double dz = jugador.getZ() - this.getZ();
        double dy = jugador.getEyeY() - this.getEyeY();
        float giro = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float inclinacion = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        this.setYRot(giro);
        this.setYBodyRot(giro);
        this.setYHeadRot(giro);
        this.setXRot(inclinacion);
    }

    private void desaparecer() {
        if (this.level() instanceof ServerLevel nivel) {
            nivel.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 0.8D, this.getZ(), 14, 0.2D, 0.45D, 0.2D, 0.01D);
            nivel.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.AMBIENT_CAVE, SoundSource.AMBIENT, 0.8F, 0.6F);
        }
        this.discard();
    }

    /** Si le pegas, se va. */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (!this.level().isClientSide) {
            this.desaparecer();
        }
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void doPush(Entity otro) {
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distanciaAlJugador) {
        return true;
    }
}
