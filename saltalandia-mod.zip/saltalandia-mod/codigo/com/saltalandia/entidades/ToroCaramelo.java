package com.saltalandia.entidades;

import com.saltalandia.registro.ModEntidades;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/**
 * Toro Caramelo: toro color caramelo con grandes cuernos dorados (vive en las Praderas Saltarinas).
 * Se cria con trigo y suelta carne y cuero. Es un toro: no da leche.
 */
public class ToroCaramelo extends Cow {

    public ToroCaramelo(EntityType<? extends ToroCaramelo> type, Level level) {
        super(type, level);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.getItemInHand(hand).is(Items.BUCKET)) {
            return InteractionResult.PASS;
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public ToroCaramelo getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return ModEntidades.TORO_CARAMELO.get().create(level);
    }
}
