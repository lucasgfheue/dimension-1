package com.saltalandia.entidades.ia;

import com.saltalandia.eventos.EstadoDia;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;

/** Desde el dia 8 los malos te persiguen aunque no te vean (saben donde estas). */
public class AtaqueFuriosoGoal extends MeleeAttackGoal {

    public AtaqueFuriosoGoal(PathfinderMob malo, double velocidad) {
        super(malo, velocidad, true);
    }

    @Override
    public boolean canUse() {
        return EstadoDia.dia(this.mob.level()) >= 8 && super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        return EstadoDia.dia(this.mob.level()) >= 8 && super.canContinueToUse();
    }
}
