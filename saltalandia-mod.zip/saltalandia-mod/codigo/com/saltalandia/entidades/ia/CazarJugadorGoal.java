package com.saltalandia.entidades.ia;

import com.saltalandia.eventos.EstadoDia;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;

/**
 * Busca al jugador mas cercano usando el rango de vision actual (que crece con la furia).
 * Con atraviesaParedes=true lo encuentra aunque haya bloques en el medio (los malos, desde el dia 8).
 */
public class CazarJugadorGoal extends NearestAttackableTargetGoal<Player> {
    private final boolean atraviesaParedes;
    private final int diaMinimo;

    public CazarJugadorGoal(Mob malo, boolean atraviesaParedes, int diaMinimo) {
        super(malo, Player.class, !atraviesaParedes);
        this.atraviesaParedes = atraviesaParedes;
        this.diaMinimo = diaMinimo;
    }

    @Override
    public boolean canUse() {
        return EstadoDia.dia(this.mob.level()) >= this.diaMinimo && super.canUse();
    }

    @Override
    protected void findTarget() {
        TargetingConditions condiciones = TargetingConditions.forCombat().range(this.getFollowDistance());
        this.targetConditions = this.atraviesaParedes ? condiciones.ignoreLineOfSight() : condiciones;
        super.findTarget();
    }
}
