package com.saltalandia.entidades.ia;

import com.saltalandia.eventos.EstadoDia;
import com.saltalandia.registro.ModBloques;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;

/**
 * Desde el dia 6, si un malo no puede llegar hasta el jugador, rompe el bloque que tiene adelante
 * (o arriba / abajo si el jugador esta mas alto o mas bajo). Los dias 6 y 7 tarda mucho (de 5 a 20 segundos
 * por bloque); desde el dia 8 rompe en 1 o 2 segundos. Respeta la regla mobGriefing.
 */
public final class RomperBloquesGoal extends Goal {
    private final PathfinderMob malo;
    private BlockPos bloque;
    private int progreso;
    private int necesario;
    private int etapa = -1;
    private int espera;

    public RomperBloquesGoal(PathfinderMob malo) {
        this.malo = malo;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (this.espera > 0) {
            this.espera--;
            return false;
        }
        this.espera = 10;
        Level nivel = this.malo.level();
        int dia = EstadoDia.dia(nivel);
        if (dia < 6 || dia >= 10 || !nivel.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            return false;
        }
        LivingEntity objetivo = this.malo.getTarget();
        if (objetivo == null || !objetivo.isAlive()) {
            return false;
        }
        double distancia = this.malo.distanceToSqr(objetivo);
        if (distancia > 32.0D * 32.0D || distancia < 2.2D * 2.2D || !trabado(this.malo)) {
            return false;
        }
        this.bloque = this.elegirBloque(objetivo);
        return this.bloque != null;
    }

    /** No tiene camino hasta el objetivo (o se choco con algo). */
    static boolean trabado(PathfinderMob malo) {
        PathNavigation navegacion = malo.getNavigation();
        Path camino = navegacion.getPath();
        return camino == null || navegacion.isDone() || !camino.canReach() || malo.horizontalCollision;
    }

    private BlockPos elegirBloque(LivingEntity objetivo) {
        BlockPos pies = this.malo.blockPosition();
        double dx = objetivo.getX() - this.malo.getX();
        double dz = objetivo.getZ() - this.malo.getZ();
        double dy = objetivo.getY() - this.malo.getY();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (dy > 1.5D && horizontal < 2.5D) {
            return this.sePuedeRomper(pies.above(2)) ? pies.above(2) : null;      // el jugador esta arriba: rompe el techo
        }
        if (dy < -1.5D && horizontal < 2.5D) {
            return this.sePuedeRomper(pies.below()) ? pies.below() : null;        // el jugador esta abajo: cava
        }
        BlockPos frente = pies.relative(Direction.getNearest(dx, 0.0D, dz));
        if (this.sePuedeRomper(frente.above())) {
            return frente.above();
        }
        if (this.sePuedeRomper(frente)) {
            return frente;
        }
        if (dy > 0.5D && this.sePuedeRomper(pies.above(2))) {
            return pies.above(2);                                                // despeja arriba para poder saltar
        }
        return null;
    }

    private boolean sePuedeRomper(BlockPos pos) {
        Level nivel = this.malo.level();
        BlockState estado = nivel.getBlockState(pos);
        if (estado.isAir() || !estado.getFluidState().isEmpty() || estado.getCollisionShape(nivel, pos).isEmpty()) {
            return false;
        }
        float dureza = estado.getDestroySpeed(nivel, pos);
        if (dureza < 0.0F || dureza > 50.0F || estado.is(ModBloques.PORTAL_SALTARIN.get())) {
            return false;
        }
        return estado.canEntityDestroy(nivel, pos, this.malo);
    }

    @Override
    public void start() {
        this.progreso = 0;
        this.etapa = -1;
        Level nivel = this.malo.level();
        float dureza = Math.max(0.3F, Math.min(nivel.getBlockState(this.bloque).getDestroySpeed(nivel, this.bloque), 6.0F));
        int base = EstadoDia.dia(nivel) >= 8 ? 14 : 180;
        this.necesario = Math.max(6, (int) (base * dureza));
        this.malo.getNavigation().stop();
    }

    @Override
    public boolean canContinueToUse() {
        if (this.bloque == null || EstadoDia.dia(this.malo.level()) >= 10) {
            return false;
        }
        LivingEntity objetivo = this.malo.getTarget();
        return objetivo != null && objetivo.isAlive() && !this.malo.level().getBlockState(this.bloque).isAir()
                && this.malo.distanceToSqr(this.bloque.getX() + 0.5D, this.bloque.getY() + 0.5D, this.bloque.getZ() + 0.5D) < 16.0D;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        Level nivel = this.malo.level();
        this.malo.getNavigation().stop();
        this.malo.getLookControl().setLookAt(this.bloque.getX() + 0.5D, this.bloque.getY() + 0.5D, this.bloque.getZ() + 0.5D);
        BlockState estado = nivel.getBlockState(this.bloque);
        if (this.progreso % 6 == 0) {
            this.malo.swing(InteractionHand.MAIN_HAND);
            nivel.playSound(null, this.bloque, estado.getSoundType(nivel, this.bloque, this.malo).getHitSound(), SoundSource.HOSTILE, 0.6F, 0.7F);
        }
        this.progreso++;
        int nueva = Math.min(9, this.progreso * 10 / this.necesario);
        if (nueva != this.etapa) {
            this.etapa = nueva;
            nivel.destroyBlockProgress(this.malo.getId(), this.bloque, nueva);
        }
        if (this.progreso >= this.necesario) {
            nivel.destroyBlockProgress(this.malo.getId(), this.bloque, -1);
            nivel.destroyBlock(this.bloque, true, this.malo);
            this.bloque = null;
        }
    }

    @Override
    public void stop() {
        if (this.bloque != null) {
            this.malo.level().destroyBlockProgress(this.malo.getId(), this.bloque, -1);
        }
        this.bloque = null;
    }
}
