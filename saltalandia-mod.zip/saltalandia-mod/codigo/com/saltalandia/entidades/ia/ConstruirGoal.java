package com.saltalandia.entidades.ia;

import com.saltalandia.eventos.EstadoDia;
import com.saltalandia.registro.ModBloques;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Dia 9: si el jugador esta muy alto (o del otro lado de un hueco) y no hay camino, el malo pone bloques
 * de Tierra Dulce para alcanzarlo: salta y pone un bloque debajo (torre) o pone el piso adelante (puente).
 * Cada malo puede poner hasta 48 bloques. Respeta la regla mobGriefing.
 */
public final class ConstruirGoal extends Goal {
    private static final int MAXIMO = 48;

    private final PathfinderMob malo;
    private int colocados;
    private int espera;
    private int ticks;
    private BlockPos salto;

    public ConstruirGoal(PathfinderMob malo) {
        this.malo = malo;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        if (this.espera > 0) {
            this.espera--;
            return false;
        }
        this.espera = 10;
        return this.hayQueConstruir() && RomperBloquesGoal.trabado(this.malo);
    }

    private boolean hayQueConstruir() {
        Level nivel = this.malo.level();
        int dia = EstadoDia.dia(nivel);
        if (dia < 9 || dia >= 10 || this.colocados >= MAXIMO || !nivel.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            return false;
        }
        LivingEntity objetivo = this.malo.getTarget();
        if (objetivo == null || !objetivo.isAlive()) {
            return false;
        }
        double dy = objetivo.getY() - this.malo.getY();
        double horizontal = this.horizontal(objetivo);
        return (dy >= 2.5D && horizontal <= 4.0D) || (Math.abs(dy) < 2.0D && horizontal > 1.8D && horizontal < 16.0D && this.hayHueco(objetivo));
    }

    private double horizontal(LivingEntity objetivo) {
        double dx = objetivo.getX() - this.malo.getX();
        double dz = objetivo.getZ() - this.malo.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    private Direction haciaObjetivo(LivingEntity objetivo) {
        return Direction.getNearest(objetivo.getX() - this.malo.getX(), 0.0D, objetivo.getZ() - this.malo.getZ());
    }

    private boolean hayHueco(LivingEntity objetivo) {
        BlockPos frente = this.malo.blockPosition().relative(this.haciaObjetivo(objetivo));
        return this.libre(frente) && this.libre(frente.above()) && this.malo.level().getBlockState(frente.below()).canBeReplaced();
    }

    private boolean libre(BlockPos pos) {
        Level nivel = this.malo.level();
        return nivel.getBlockState(pos).getCollisionShape(nivel, pos).isEmpty();
    }

    @Override
    public void start() {
        this.ticks = 0;
        this.salto = null;
    }

    @Override
    public boolean canContinueToUse() {
        return this.ticks < 400 && this.hayQueConstruir();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        this.ticks++;
        LivingEntity objetivo = this.malo.getTarget();
        if (objetivo == null) {
            return;
        }
        this.malo.getLookControl().setLookAt(objetivo, 30.0F, 30.0F);
        double dy = objetivo.getY() - this.malo.getY();
        if (dy >= 2.5D && this.horizontal(objetivo) <= 4.0D) {
            this.torre();
        } else {
            this.puente(objetivo);
        }
    }

    /** Salta y, cuando ya subio, pone un bloque donde tenia los pies. */
    private void torre() {
        if (this.malo.onGround()) {
            BlockPos pies = this.malo.blockPosition();
            if (this.libre(pies.above(2))) {
                this.salto = pies;
                this.malo.getNavigation().stop();
                this.malo.getJumpControl().jump();
            }
        } else if (this.salto != null && this.malo.getY() > this.salto.getY() + 1.02D) {
            this.poner(this.salto);
            this.salto = null;
        }
    }

    /** Pone el piso adelante (hacia el objetivo) y camina encima. */
    private void puente(LivingEntity objetivo) {
        BlockPos frente = this.malo.blockPosition().relative(this.haciaObjetivo(objetivo));
        if (this.ticks % 8 == 0 && this.malo.onGround() && this.libre(frente) && this.malo.level().getBlockState(frente.below()).canBeReplaced()) {
            this.poner(frente.below());
        }
        this.malo.getMoveControl().setWantedPosition(frente.getX() + 0.5D, this.malo.getY(), frente.getZ() + 0.5D, 1.0D);
    }

    private void poner(BlockPos pos) {
        Level nivel = this.malo.level();
        BlockState actual = nivel.getBlockState(pos);
        if (!actual.canBeReplaced() || !nivel.getEntitiesOfClass(LivingEntity.class, new AABB(pos)).isEmpty()) {
            return;
        }
        BlockState tierra = ModBloques.TIERRA_DULCE.get().defaultBlockState();
        if (nivel.setBlock(pos, tierra, Block.UPDATE_ALL)) {
            this.colocados++;
            nivel.playSound(null, pos, tierra.getSoundType(nivel, pos, this.malo).getPlaceSound(), SoundSource.HOSTILE, 1.0F, 0.8F);
        }
    }
}
