package com.saltalandia.entidades.ia;

import com.saltalandia.Saltalandia;
import com.saltalandia.eventos.EstadoDia;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/**
 * Los malos se enfurecen con los dias:
 * dia 6 y 7 -> 30% mas rapidos, 60% mas dano y 50% mas rango de vision;
 * dia 8 en adelante -> 45% mas rapidos, el doble de dano y el doble de rango de vision.
 */
public final class Furia {
    private static final ResourceLocation VELOCIDAD = Saltalandia.id("furia_velocidad");
    private static final ResourceLocation DANO = Saltalandia.id("furia_dano");
    private static final ResourceLocation RANGO = Saltalandia.id("furia_rango");

    private Furia() {
    }

    /** 0 = normal, 1 = dias 6-7, 2 = dia 8 en adelante. */
    public static int nivel(Level nivel) {
        int dia = EstadoDia.dia(nivel);
        return dia >= 8 ? 2 : (dia >= 6 ? 1 : 0);
    }

    /** Multiplicador de velocidad (para el Brinco Fantasma, que no camina). */
    public static double factorVelocidad(Level nivel) {
        int furia = nivel(nivel);
        return furia == 2 ? 1.45D : (furia == 1 ? 1.3D : 1.0D);
    }

    /** Pone (o saca) los modificadores segun el dia. Se llama cada 2 segundos desde cada malo. */
    public static void actualizar(Mob malo) {
        int furia = nivel(malo.level());
        poner(malo, Attributes.MOVEMENT_SPEED, VELOCIDAD, furia == 2 ? 0.45D : (furia == 1 ? 0.3D : 0.0D));
        poner(malo, Attributes.ATTACK_DAMAGE, DANO, furia == 2 ? 1.0D : (furia == 1 ? 0.6D : 0.0D));
        poner(malo, Attributes.FOLLOW_RANGE, RANGO, furia == 2 ? 1.0D : (furia == 1 ? 0.5D : 0.0D));
    }

    private static void poner(Mob malo, Holder<Attribute> atributo, ResourceLocation id, double cantidad) {
        AttributeInstance instancia = malo.getAttribute(atributo);
        if (instancia == null) {
            return;
        }
        if (cantidad == 0.0D) {
            if (instancia.hasModifier(id)) {
                instancia.removeModifier(id);
            }
        } else {
            instancia.addOrUpdateTransientModifier(new AttributeModifier(id, cantidad, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }
}
