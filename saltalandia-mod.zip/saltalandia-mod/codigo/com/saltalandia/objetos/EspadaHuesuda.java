package com.saltalandia.objetos;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/**
 * Espada Huesuda: hoja de hueso, guarda de caparazon y una gema en el mango.
 * La lleva el Huesudo (5% de soltarla). Pega como una espada de hierro
 * y deja lento al que golpea durante 3 segundos.
 */
public class EspadaHuesuda extends SwordItem {

    public EspadaHuesuda(Tier material, Properties propiedades) {
        super(material, propiedades);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (super.hurtEnemy(stack, target, attacker)) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0), attacker);
            return true;
        }
        return false;
    }
}
