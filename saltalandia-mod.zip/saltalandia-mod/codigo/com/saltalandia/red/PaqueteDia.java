package com.saltalandia.red;

import com.saltalandia.Saltalandia;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** El servidor le avisa al cliente en que dia de Saltalandia esta (0 = fuera de Saltalandia). */
public record PaqueteDia(int dia) implements CustomPacketPayload {
    public static final Type<PaqueteDia> TIPO = new Type<>(Saltalandia.id("dia"));
    public static final StreamCodec<RegistryFriendlyByteBuf, PaqueteDia> CODEC = CustomPacketPayload.codec(PaqueteDia::escribir, PaqueteDia::new);

    public PaqueteDia(FriendlyByteBuf buf) {
        this(buf.readVarInt());
    }

    public void escribir(FriendlyByteBuf buf) {
        buf.writeVarInt(this.dia);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TIPO;
    }
}
