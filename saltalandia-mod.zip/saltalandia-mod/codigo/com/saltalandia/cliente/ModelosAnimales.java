package com.saltalandia.cliente;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Capas de los 4 animales: la forma de la vaca (con cuernos de toro), la llama, el lobo y la gallina
 * de Minecraft, con texturas propias.
 */
public final class ModelosAnimales {
    private static final float MEDIO_PI = (float) Math.PI / 2.0F;

    private ModelosAnimales() {
    }

    /** Toro: como la vaca, sin ubre y con cuernos grandes que salen hacia los costados y suben. */
    public static LayerDefinition capaToro() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        raiz.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 6.0F)
                .texOffs(22, 0).addBox(-7.0F, -4.0F, -4.0F, 3.0F, 1.0F, 1.0F)
                .texOffs(22, 0).addBox(4.0F, -4.0F, -4.0F, 3.0F, 1.0F, 1.0F)
                .texOffs(30, 0).addBox(-7.0F, -6.0F, -4.0F, 1.0F, 2.0F, 1.0F)
                .texOffs(30, 0).addBox(6.0F, -6.0F, -4.0F, 1.0F, 2.0F, 1.0F), PartPose.offset(0.0F, 4.0F, -8.0F));
        raiz.addOrReplaceChild("body", CubeListBuilder.create().texOffs(18, 4).addBox(-6.0F, -10.0F, -7.0F, 12.0F, 18.0F, 10.0F),
                PartPose.offsetAndRotation(0.0F, 5.0F, 2.0F, MEDIO_PI, 0.0F, 0.0F));
        CubeListBuilder pata = CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F);
        CubeListBuilder pataEspejo = CubeListBuilder.create().mirror().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F);
        raiz.addOrReplaceChild("right_hind_leg", pata, PartPose.offset(-4.0F, 12.0F, 7.0F));
        raiz.addOrReplaceChild("left_hind_leg", pataEspejo, PartPose.offset(4.0F, 12.0F, 7.0F));
        raiz.addOrReplaceChild("right_front_leg", pata, PartPose.offset(-4.0F, 12.0F, -6.0F));
        raiz.addOrReplaceChild("left_front_leg", pataEspejo, PartPose.offset(4.0F, 12.0F, -6.0F));
        return LayerDefinition.create(malla, 64, 32);
    }

    /** Llama: hocico, cuello largo, orejas, cuerpo, cofres (solo se ven si lleva) y 4 patas. */
    public static LayerDefinition capaLlama() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        raiz.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2.0F, -14.0F, -10.0F, 4.0F, 4.0F, 9.0F)
                .texOffs(0, 14).addBox(-4.0F, -16.0F, -6.0F, 8.0F, 18.0F, 6.0F)
                .texOffs(17, 0).addBox(-4.0F, -19.0F, -4.0F, 3.0F, 3.0F, 2.0F)
                .texOffs(17, 0).addBox(1.0F, -19.0F, -4.0F, 3.0F, 3.0F, 2.0F), PartPose.offset(0.0F, 7.0F, -6.0F));
        raiz.addOrReplaceChild("body", CubeListBuilder.create().texOffs(29, 0).addBox(-6.0F, -10.0F, -7.0F, 12.0F, 18.0F, 10.0F),
                PartPose.offsetAndRotation(0.0F, 5.0F, 2.0F, MEDIO_PI, 0.0F, 0.0F));
        raiz.addOrReplaceChild("right_chest", CubeListBuilder.create().texOffs(45, 28).addBox(-3.0F, 0.0F, 0.0F, 8.0F, 8.0F, 3.0F),
                PartPose.offsetAndRotation(-8.5F, 3.0F, 3.0F, 0.0F, MEDIO_PI, 0.0F));
        raiz.addOrReplaceChild("left_chest", CubeListBuilder.create().texOffs(45, 41).addBox(-3.0F, 0.0F, 0.0F, 8.0F, 8.0F, 3.0F),
                PartPose.offsetAndRotation(5.5F, 3.0F, 3.0F, 0.0F, MEDIO_PI, 0.0F));
        CubeListBuilder pata = CubeListBuilder.create().texOffs(29, 29).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 14.0F, 4.0F);
        raiz.addOrReplaceChild("right_hind_leg", pata, PartPose.offset(-3.5F, 10.0F, 6.0F));
        raiz.addOrReplaceChild("left_hind_leg", pata, PartPose.offset(3.5F, 10.0F, 6.0F));
        raiz.addOrReplaceChild("right_front_leg", pata, PartPose.offset(-3.5F, 10.0F, -5.0F));
        raiz.addOrReplaceChild("left_front_leg", pata, PartPose.offset(3.5F, 10.0F, -5.0F));
        return LayerDefinition.create(malla, 128, 64);
    }

    /** Lobo: cabeza con orejas y hocico, cuerpo, melena, 4 patas y cola (igual forma que el lobo). */
    public static LayerDefinition capaLobo() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition cabeza = raiz.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(-1.0F, 13.5F, -7.0F));
        cabeza.addOrReplaceChild("real_head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2.0F, -3.0F, -2.0F, 6.0F, 6.0F, 4.0F)
                .texOffs(16, 14).addBox(-2.0F, -5.0F, 0.0F, 2.0F, 2.0F, 1.0F)
                .texOffs(16, 14).addBox(2.0F, -5.0F, 0.0F, 2.0F, 2.0F, 1.0F)
                .texOffs(0, 10).addBox(-0.5F, -0.001F, -5.0F, 3.0F, 3.0F, 4.0F), PartPose.ZERO);
        raiz.addOrReplaceChild("body", CubeListBuilder.create().texOffs(18, 14).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 9.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 14.0F, 2.0F, MEDIO_PI, 0.0F, 0.0F));
        raiz.addOrReplaceChild("upper_body", CubeListBuilder.create().texOffs(21, 0).addBox(-3.0F, -3.0F, -3.0F, 8.0F, 6.0F, 7.0F),
                PartPose.offsetAndRotation(-1.0F, 14.0F, -3.0F, MEDIO_PI, 0.0F, 0.0F));
        CubeListBuilder pata = CubeListBuilder.create().texOffs(0, 18).addBox(0.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F);
        raiz.addOrReplaceChild("right_hind_leg", pata, PartPose.offset(-2.5F, 16.0F, 7.0F));
        raiz.addOrReplaceChild("left_hind_leg", pata, PartPose.offset(0.5F, 16.0F, 7.0F));
        raiz.addOrReplaceChild("right_front_leg", pata, PartPose.offset(-2.5F, 16.0F, -4.0F));
        raiz.addOrReplaceChild("left_front_leg", pata, PartPose.offset(0.5F, 16.0F, -4.0F));
        PartDefinition cola = raiz.addOrReplaceChild("tail", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-1.0F, 12.0F, 8.0F, (float) Math.PI / 5.0F, 0.0F, 0.0F));
        cola.addOrReplaceChild("real_tail", CubeListBuilder.create().texOffs(9, 18).addBox(0.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.ZERO);
        return LayerDefinition.create(malla, 64, 32);
    }

    /** Gallina: cabeza, pico, cresta, cuerpo, 2 patas y 2 alas. */
    public static LayerDefinition capaGallina() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        raiz.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -6.0F, -2.0F, 4.0F, 6.0F, 3.0F), PartPose.offset(0.0F, 15.0F, -4.0F));
        raiz.addOrReplaceChild("beak", CubeListBuilder.create().texOffs(14, 0).addBox(-2.0F, -4.0F, -4.0F, 4.0F, 2.0F, 2.0F), PartPose.offset(0.0F, 15.0F, -4.0F));
        raiz.addOrReplaceChild("red_thing", CubeListBuilder.create().texOffs(14, 4).addBox(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(0.0F, 15.0F, -4.0F));
        raiz.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 9).addBox(-3.0F, -4.0F, -3.0F, 6.0F, 8.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, MEDIO_PI, 0.0F, 0.0F));
        CubeListBuilder pata = CubeListBuilder.create().texOffs(26, 0).addBox(-1.0F, 0.0F, -3.0F, 3.0F, 5.0F, 3.0F);
        raiz.addOrReplaceChild("right_leg", pata, PartPose.offset(-2.0F, 19.0F, 1.0F));
        raiz.addOrReplaceChild("left_leg", pata, PartPose.offset(1.0F, 19.0F, 1.0F));
        raiz.addOrReplaceChild("right_wing", CubeListBuilder.create().texOffs(24, 13).addBox(0.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F), PartPose.offset(-4.0F, 13.0F, 0.0F));
        raiz.addOrReplaceChild("left_wing", CubeListBuilder.create().texOffs(24, 13).addBox(-1.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F), PartPose.offset(4.0F, 13.0F, 0.0F));
        return LayerDefinition.create(malla, 64, 32);
    }
}
