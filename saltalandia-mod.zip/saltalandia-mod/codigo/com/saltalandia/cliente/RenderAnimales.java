package com.saltalandia.cliente;

import com.saltalandia.Saltalandia;
import com.saltalandia.entidades.GallinaConfite;
import com.saltalandia.entidades.ToroCaramelo;
import net.minecraft.client.model.ChickenModel;
import net.minecraft.client.model.CowModel;
import net.minecraft.client.model.LlamaModel;
import net.minecraft.client.model.WolfModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.LlamaDecorLayer;
import net.minecraft.client.renderer.entity.layers.WolfArmorLayer;
import net.minecraft.client.renderer.entity.layers.WolfCollarLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.animal.horse.Llama;

/** Renderizadores de los 4 animales (modelos de vaca, llama, lobo y gallina con texturas propias). */
public final class RenderAnimales {
    private RenderAnimales() {
    }

    /** Toro Caramelo. */
    public static class Toro extends MobRenderer<ToroCaramelo, CowModel<ToroCaramelo>> {
        private static final ResourceLocation TEXTURA = Saltalandia.id("textures/entity/toro_caramelo.png");

        public Toro(EntityRendererProvider.Context contexto) {
            super(contexto, new CowModel<>(contexto.bakeLayer(SaltalandiaCliente.CAPA_TORO)), 0.7F);
        }

        @Override
        public ResourceLocation getTextureLocation(ToroCaramelo entidad) {
            return TEXTURA;
        }
    }

    /** Llama Algodon (tambien dibuja la alfombra si se la ponen). */
    public static class LlamaRender extends MobRenderer<Llama, LlamaModel<Llama>> {
        private static final ResourceLocation TEXTURA = Saltalandia.id("textures/entity/llama_algodon.png");

        @SuppressWarnings("this-escape")
        public LlamaRender(EntityRendererProvider.Context contexto) {
            super(contexto, new LlamaModel<>(contexto.bakeLayer(SaltalandiaCliente.CAPA_LLAMA)), 0.7F);
            this.addLayer(new LlamaDecorLayer(this, contexto.getModelSet()));
        }

        @Override
        public ResourceLocation getTextureLocation(Llama entidad) {
            return TEXTURA;
        }
    }

    /** Lobo Menta (dibuja el collar cuando esta domesticado y la armadura de lobo). */
    public static class Lobo extends MobRenderer<Wolf, WolfModel<Wolf>> {
        private static final ResourceLocation TEXTURA = Saltalandia.id("textures/entity/lobo_menta.png");

        @SuppressWarnings("this-escape")
        public Lobo(EntityRendererProvider.Context contexto) {
            super(contexto, new WolfModel<>(contexto.bakeLayer(SaltalandiaCliente.CAPA_LOBO)), 0.5F);
            this.addLayer(new WolfArmorLayer(this, contexto.getModelSet()));
            this.addLayer(new WolfCollarLayer(this));
        }

        @Override
        public ResourceLocation getTextureLocation(Wolf entidad) {
            return TEXTURA;
        }

        @Override
        protected float getBob(Wolf lobo, float parcial) {
            return lobo.getTailAngle();
        }
    }

    /** Gallina Confite (aletea igual que una gallina normal). */
    public static class Gallina extends MobRenderer<GallinaConfite, ChickenModel<GallinaConfite>> {
        private static final ResourceLocation TEXTURA = Saltalandia.id("textures/entity/gallina_confite.png");

        public Gallina(EntityRendererProvider.Context contexto) {
            super(contexto, new ChickenModel<>(contexto.bakeLayer(SaltalandiaCliente.CAPA_GALLINA)), 0.3F);
        }

        @Override
        public ResourceLocation getTextureLocation(GallinaConfite entidad) {
            return TEXTURA;
        }

        @Override
        protected float getBob(GallinaConfite gallina, float parcial) {
            float aleteo = Mth.lerp(parcial, gallina.oFlap, gallina.flap);
            float velocidad = Mth.lerp(parcial, gallina.oFlapSpeed, gallina.flapSpeed);
            return (Mth.sin(aleteo) + 1.0F) * velocidad;
        }
    }
}
