package com.saltalandia.cliente;

import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.monster.Monster;

/** Modelo de jugador translucido que flota con las piernas colgando y los brazos estirados (Brinco Fantasma). */
public class ModeloFantasma<T extends Monster> extends HumanoidModel<T> {

    public ModeloFantasma(ModelPart raiz) {
        super(raiz, RenderType::entityTranslucent);
    }

    @Override
    public void setupAnim(T entidad, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entidad, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, entidad.isAggressive(), this.attackTime, ageInTicks);
        float vaiven = Mth.sin(ageInTicks * 0.1F) * 0.12F;
        this.rightLeg.xRot = 0.45F + vaiven;
        this.leftLeg.xRot = 0.35F - vaiven;
        this.rightLeg.yRot = 0.0F;
        this.leftLeg.yRot = 0.0F;
    }
}
