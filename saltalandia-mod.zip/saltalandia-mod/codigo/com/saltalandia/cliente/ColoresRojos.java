package com.saltalandia.cliente;

import com.saltalandia.Saltalandia;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Dia 9: el agua y el pasto de Saltalandia se vuelven rojos. Cambia (solo en el cliente) los colores de agua,
 * niebla bajo el agua y pasto de los 3 biomas de Saltalandia, y los vuelve a poner como estaban si el dia baja.
 */
final class ColoresRojos {
    private static final Logger LOG = LoggerFactory.getLogger("saltalandia");
    static final int PASTO_ROJO = 0xB3201A;
    private static final int AGUA_ROJA = 0x9A0B0B;
    private static final int NIEBLA_ROJA = 0x330000;
    private static final List<ResourceKey<Biome>> BIOMAS = List.of(
            ResourceKey.create(Registries.BIOME, Saltalandia.id("praderas_saltarinas")),
            ResourceKey.create(Registries.BIOME, Saltalandia.id("bosque_pompon")),
            ResourceKey.create(Registries.BIOME, Saltalandia.id("jardin_algodon")));
    /** Colores originales de cada bioma cambiado: agua, niebla del agua y pasto. */
    private static final Map<BiomeSpecialEffects, Object[]> ORIGINALES = new WeakHashMap<>();

    private static boolean preparado;
    private static Field agua;
    private static Field niebla;
    private static Field pasto;

    private ColoresRojos() {
    }

    /** Pone (rojo=true) o saca los colores rojos. Devuelve true si cambio algo. */
    static boolean aplicar(Level nivel, boolean rojo) {
        if (!preparar()) {
            return false;
        }
        Registry<Biome> biomas = nivel.registryAccess().registryOrThrow(Registries.BIOME);
        boolean cambio = false;
        for (ResourceKey<Biome> clave : BIOMAS) {
            Biome bioma = biomas.get(clave);
            if (bioma != null) {
                cambio |= aplicar(bioma.getSpecialEffects(), rojo);
            }
        }
        return cambio;
    }

    private static boolean aplicar(BiomeSpecialEffects efectos, boolean rojo) {
        try {
            if (rojo) {
                if (ORIGINALES.containsKey(efectos)) {
                    return false;
                }
                ORIGINALES.put(efectos, new Object[] {agua.getInt(efectos), niebla.getInt(efectos), pasto.get(efectos)});
                agua.setInt(efectos, AGUA_ROJA);
                niebla.setInt(efectos, NIEBLA_ROJA);
                pasto.set(efectos, Optional.of(PASTO_ROJO));
                return true;
            }
            Object[] original = ORIGINALES.remove(efectos);
            if (original == null) {
                return false;
            }
            agua.setInt(efectos, (Integer) original[0]);
            niebla.setInt(efectos, (Integer) original[1]);
            pasto.set(efectos, original[2]);
            return true;
        } catch (ReflectiveOperationException | RuntimeException error) {
            LOG.warn("Saltalandia: no se pudieron cambiar los colores del agua y el pasto", error);
            agua = null;
            return false;
        }
    }

    private static boolean preparar() {
        if (!preparado) {
            preparado = true;
            try {
                agua = campo("waterColor");
                niebla = campo("waterFogColor");
                pasto = campo("grassColorOverride");
            } catch (ReflectiveOperationException | RuntimeException error) {
                LOG.warn("Saltalandia: el agua roja no esta disponible en esta version", error);
                agua = null;
            }
        }
        return agua != null;
    }

    private static Field campo(String nombre) throws NoSuchFieldException {
        Field campo = BiomeSpecialEffects.class.getDeclaredField(nombre);
        campo.setAccessible(true);
        return campo;
    }
}
