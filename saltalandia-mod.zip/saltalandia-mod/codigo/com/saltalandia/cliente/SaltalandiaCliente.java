package com.saltalandia.cliente;

import com.saltalandia.Saltalandia;
import com.saltalandia.entidades.Brinco;
import com.saltalandia.entidades.Grunon;
import com.saltalandia.entidades.Huesudo;
import com.saltalandia.registro.ModEntidades;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.SkeletonModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Parte del mod que solo corre en el cliente: modelos y dibujo de los personajes. */
@Mod(value = Saltalandia.MODID, dist = Dist.CLIENT)
public class SaltalandiaCliente {
    /** Modelo de jugador clasico (skin de 64x32). */
    public static final ModelLayerLocation CAPA_JUGADOR = new ModelLayerLocation(Saltalandia.id("jugador_tortuga"), "main");
    /** Modelo de esqueleto (brazos y piernas de 2x12x2). */
    public static final ModelLayerLocation CAPA_ESQUELETO = new ModelLayerLocation(Saltalandia.id("esqueleto_tortuga"), "main");

    public SaltalandiaCliente(IEventBus modEventBus) {
        modEventBus.addListener(SaltalandiaCliente::registrarCapas);
        modEventBus.addListener(SaltalandiaCliente::registrarRenders);
    }

    private static void registrarCapas(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(CAPA_JUGADOR, () -> LayerDefinition.create(HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F), 64, 32));
        event.registerLayerDefinition(CAPA_ESQUELETO, SkeletonModel::createBodyLayer);
    }

    private static void registrarRenders(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntidades.BRINCO.get(),
                contexto -> new RenderHumanoide<Brinco, HumanoidModel<Brinco>>(contexto, new HumanoidModel<>(contexto.bakeLayer(CAPA_JUGADOR)), "brinco"));
        event.registerEntityRenderer(ModEntidades.GRUNON.get(),
                contexto -> new RenderHumanoide<Grunon, ModeloZombi<Grunon>>(contexto, new ModeloZombi<>(contexto.bakeLayer(CAPA_JUGADOR)), "grunon"));
        event.registerEntityRenderer(ModEntidades.HUESUDO.get(),
                contexto -> new RenderHumanoide<Huesudo, ModeloEsqueleto<Huesudo>>(contexto, new ModeloEsqueleto<>(contexto.bakeLayer(CAPA_ESQUELETO)), "huesudo"));
        event.registerEntityRenderer(ModEntidades.BRINCO_FANTASMA.get(), RenderFantasma::new);
    }
}
