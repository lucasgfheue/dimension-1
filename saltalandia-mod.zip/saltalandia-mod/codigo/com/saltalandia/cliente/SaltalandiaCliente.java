package com.saltalandia.cliente;

import com.saltalandia.Saltalandia;
import com.saltalandia.entidades.Brinco;
import com.saltalandia.entidades.Grunon;
import com.saltalandia.entidades.Huesudo;
import com.saltalandia.registro.ModEntidades;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.SkeletonModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Parte del mod que solo corre en el cliente: modelos y dibujo de los personajes. */
@Mod(value = Saltalandia.MODID, dist = Dist.CLIENT)
public class SaltalandiaCliente {
    /** Modelo de jugador clasico (skin de 64x32). */
    public static final ModelLayerLocation CAPA_JUGADOR = new ModelLayerLocation(Saltalandia.id("jugador_tortuga"), "main");
    /** Modelo de esqueleto (brazos y piernas de 2x12x2). */
    public static final ModelLayerLocation CAPA_ESQUELETO = new ModelLayerLocation(Saltalandia.id("esqueleto_tortuga"), "main");
    /** Animales: forma de toro, llama, lobo y gallina con texturas propias. */
    public static final ModelLayerLocation CAPA_TORO = new ModelLayerLocation(Saltalandia.id("toro_caramelo"), "main");
    public static final ModelLayerLocation CAPA_LLAMA = new ModelLayerLocation(Saltalandia.id("llama_algodon"), "main");
    public static final ModelLayerLocation CAPA_LOBO = new ModelLayerLocation(Saltalandia.id("lobo_menta"), "main");
    public static final ModelLayerLocation CAPA_GALLINA = new ModelLayerLocation(Saltalandia.id("gallina_confite"), "main");

    public SaltalandiaCliente(IEventBus modEventBus) {
        modEventBus.addListener(SaltalandiaCliente::registrarCapas);
        modEventBus.addListener(SaltalandiaCliente::registrarRenders);
    }

    private static void registrarCapas(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(CAPA_JUGADOR, () -> LayerDefinition.create(HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F), 64, 32));
        event.registerLayerDefinition(CAPA_ESQUELETO, SkeletonModel::createBodyLayer);
        event.registerLayerDefinition(CAPA_TORO, ModelosAnimales::capaToro);
        event.registerLayerDefinition(CAPA_LLAMA, ModelosAnimales::capaLlama);
        event.registerLayerDefinition(CAPA_LOBO, ModelosAnimales::capaLobo);
        event.registerLayerDefinition(CAPA_GALLINA, ModelosAnimales::capaGallina);
    }

    private static void registrarRenders(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntidades.BRINCO.get(),
                contexto -> new RenderHumanoide<Brinco, HumanoidModel<Brinco>>(contexto, new HumanoidModel<>(contexto.bakeLayer(CAPA_JUGADOR)), "brinco"));
        event.registerEntityRenderer(ModEntidades.GRUNON.get(),
                contexto -> new RenderHumanoide<Grunon, ModeloZombi<Grunon>>(contexto, new ModeloZombi<>(contexto.bakeLayer(CAPA_JUGADOR)), "grunon"));
        event.registerEntityRenderer(ModEntidades.HUESUDO.get(),
                contexto -> new RenderHumanoide<Huesudo, ModeloEsqueleto<Huesudo>>(contexto, new ModeloEsqueleto<>(contexto.bakeLayer(CAPA_ESQUELETO)), "huesudo"));
        event.registerEntityRenderer(ModEntidades.BRINCO_FANTASMA.get(), RenderFantasma::new);
        event.registerEntityRenderer(ModEntidades.TORO_CARAMELO.get(), RenderAnimales.Toro::new);
        event.registerEntityRenderer(ModEntidades.LLAMA_ALGODON.get(), RenderAnimales.LlamaRender::new);
        event.registerEntityRenderer(ModEntidades.LOBO_MENTA.get(), RenderAnimales.Lobo::new);
        event.registerEntityRenderer(ModEntidades.GALLINA_CONFITE.get(), RenderAnimales.Gallina::new);
    }
}
