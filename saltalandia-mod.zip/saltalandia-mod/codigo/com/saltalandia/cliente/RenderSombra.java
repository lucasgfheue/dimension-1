package com.saltalandia.cliente;

import com.saltalandia.Saltalandia;
import com.saltalandia.entidades.BrincoSombra;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.layers.EyesLayer;

/** Brinco Sombra: el Brinco todo negro, con los ojos blancos que brillan en la oscuridad. */
public class RenderSombra extends RenderHumanoide<BrincoSombra, HumanoidModel<BrincoSombra>> {
    private static final RenderType OJOS = RenderType.eyes(Saltalandia.id("textures/entity/brinco_sombra_ojos.png"));

    @SuppressWarnings("this-escape")
    public RenderSombra(EntityRendererProvider.Context contexto) {
        super(contexto, new HumanoidModel<>(contexto.bakeLayer(SaltalandiaCliente.CAPA_JUGADOR)), "brinco_sombra");
        this.addLayer(new EyesLayer<BrincoSombra, HumanoidModel<BrincoSombra>>(this) {
            @Override
            public RenderType renderType() {
                return OJOS;
            }
        });
    }
}
