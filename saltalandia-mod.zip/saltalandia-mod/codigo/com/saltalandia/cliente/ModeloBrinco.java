package com.saltalandia.cliente;

import com.saltalandia.entidades.Brinco;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Modelo del Brinco (jugador con la skin de tortuga). Cuando esta "poseido" (desde el dia 6)
 * la cabeza se le retuerce a saltos: gira para atras, se ladea y tiembla.
 */
public class ModeloBrinco<T extends Brinco> extends HumanoidModel<T> {
    private static final float[] GIROS = {-2.7F, -1.6F, 0.0F, 1.45F, 3.1F, -0.85F, 2.25F};
    private static final float[] LADEOS = {-1.3F, -0.7F, 0.65F, 1.35F, 0.0F, -1.05F};

    public ModeloBrinco(ModelPart raiz) {
        super(raiz);
    }

    @Override
    public void setupAnim(T brinco, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(brinco, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (!brinco.estaPoseido()) {
            return;
        }
        int paso = (int) (ageInTicks / 5.0F) + brinco.getId() * 7;
        float temblor = Mth.sin(ageInTicks * 2.7F) * 0.08F;
        this.head.yRot = GIROS[Math.floorMod(paso * 31, GIROS.length)] + temblor;
        this.head.zRot = LADEOS[Math.floorMod(paso * 17 + 3, LADEOS.length)] + temblor * 1.5F;
        this.head.xRot = 0.35F * Mth.sin(ageInTicks * 0.9F);
        this.rightArm.zRot += temblor * 2.0F;
        this.leftArm.zRot -= temblor * 2.0F;
        this.hat.copyFrom(this.head);
    }
}
