package com.saltalandia.cliente;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.Mob;

/**
 * Modelo de esqueleto (brazos y piernas finitos, misma capa que SkeletonModel.createBodyLayer)
 * que pelea con espada (para el Huesudo).
 */
public class ModeloEsqueleto<T extends Mob> extends HumanoidModel<T> {

    public ModeloEsqueleto(ModelPart raiz) {
        super(raiz);
    }

    @Override
    public void setupAnim(T entidad, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entidad, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (entidad.isAggressive()) {
            AnimationUtils.swingWeaponDown(this.rightArm, this.leftArm, entidad, this.attackTime, ageInTicks);
        }
    }

    /** Los brazos son de 2 pixeles: se corre la espada para que quede en la mano (igual que el esqueleto). */
    @Override
    public void translateToHand(HumanoidArm lado, PoseStack pose) {
        float corrimiento = lado == HumanoidArm.RIGHT ? 1.0F : -1.0F;
        ModelPart brazo = this.getArm(lado);
        brazo.x += corrimiento;
        brazo.translateAndRotate(pose);
        brazo.x -= corrimiento;
    }
}
