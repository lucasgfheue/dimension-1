package com.saltalandia.cliente;

import com.mojang.blaze3d.vertex.PoseStack;
import com.saltalandia.Saltalandia;
import com.saltalandia.eventos.EstadoDia;
import com.saltalandia.registro.ModBloques;
import com.saltalandia.registro.ModItems;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Lo que pasa en la pantalla del jugador segun el dia de Saltalandia:
 * screamers rojos con ojos blancos (dias 7, 8 y 9, y uno al llegar el 10) y el pasto y el agua rojos (dia 9+).
 */
public final class EfectosCliente {
    /** Verde del Cesped Saltarin en el inventario (el del bioma, un poco mas claro). */
    private static final int VERDE = 0x69F065;
    private static final int DURACION_SCREAMER = 34;

    private static int screamer;
    private static Component textoScreamer;
    private static boolean rojoAplicado;
    private static Level nivelColoreado;

    private EfectosCliente() {
    }

    public static void registrar(IEventBus modBus) {
        modBus.addListener(EfectosCliente::capas);
        modBus.addListener(EfectosCliente::coloresBloques);
        modBus.addListener(EfectosCliente::coloresItems);
        NeoForge.EVENT_BUS.addListener(EfectosCliente::tick);
        NeoForge.EVENT_BUS.addListener(EfectosCliente::alDesconectar);
    }

    // ------------------------------------------------------------------ pasto (Cesped Saltarin tenido por el bioma)

    private static void coloresBloques(RegisterColorHandlersEvent.Block event) {
        event.register((estado, nivel, pos, tinte) -> colorPasto(nivel, pos), ModBloques.CESPED_SALTARIN.get());
    }

    private static void coloresItems(RegisterColorHandlersEvent.Item event) {
        event.register((cosa, tinte) -> 0xFF000000 | VERDE, ModItems.CESPED_SALTARIN.get());
    }

    private static int colorPasto(BlockAndTintGetter nivel, BlockPos pos) {
        if (EstadoDia.diaCliente() >= 9 && enSaltalandia()) {
            return aclarar(ColoresRojos.PASTO_ROJO);
        }
        return aclarar(nivel != null && pos != null ? BiomeColors.getAverageGrassColor(nivel, pos) : 0x5ED65A);
    }

    /** La textura del cesped es gris clara: el color del bioma se aclara un poco para que quede vivo. */
    private static int aclarar(int color) {
        int r = Math.min(255, (int) (((color >> 16) & 0xFF) * 1.12F));
        int g = Math.min(255, (int) (((color >> 8) & 0xFF) * 1.12F));
        int b = Math.min(255, (int) ((color & 0xFF) * 1.12F));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static boolean enSaltalandia() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level != null && mc.level.dimension().equals(Saltalandia.DIMENSION);
    }

    // ------------------------------------------------------------------ cada tick del cliente

    private static void tick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            return;
        }
        boolean adentro = mc.level.dimension().equals(Saltalandia.DIMENSION);
        int dia = adentro ? EstadoDia.diaCliente() : 0;

        // dia 9+: agua y pasto rojos
        boolean rojo = dia >= 9;
        if (rojo != rojoAplicado || mc.level != nivelColoreado) {
            boolean cambio = ColoresRojos.aplicar(mc.level, rojo);
            if (cambio || (rojo != rojoAplicado && adentro)) {
                mc.levelRenderer.allChanged();
            }
            rojoAplicado = rojo;
            nivelColoreado = mc.level;
        }

        // screamers
        if (screamer > 0) {
            screamer--;
            return;
        }
        if (!adentro) {
            return;
        }
        if (EstadoDia.tomarFinalPendiente()) {
            lanzar(mc, Component.translatable("screamer.saltalandia.tarde"));
        } else if (dia >= 7 && dia <= 9 && mc.screen == null && !mc.isPaused()) {
            int promedio = dia == 7 ? 7200 : (dia == 8 ? 5400 : 3600);
            if (mc.level.random.nextInt(promedio) == 0) {
                lanzar(mc, textoAlAzar(dia, mc.level.random));
            }
        }
    }

    private static Component textoAlAzar(int dia, RandomSource azar) {
        int r = azar.nextInt(4);
        if (r == 2) {
            return Component.translatable("screamer.saltalandia.dije");
        }
        if (r == 3) {
            return Component.translatable("screamer.saltalandia.tarde");
        }
        return Component.translatable(dia >= 9 ? "screamer.saltalandia.un_dia" : (dia >= 8 ? "screamer.saltalandia.dos_dias" : "screamer.saltalandia.tres_dias"));
    }

    private static void lanzar(Minecraft mc, Component texto) {
        screamer = DURACION_SCREAMER;
        textoScreamer = texto;
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ENDERMAN_STARE, 0.55F, 1.0F));
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ENDERMAN_SCREAM, 0.6F, 1.0F));
    }

    private static void alDesconectar(ClientPlayerNetworkEvent.LoggingOut event) {
        EstadoDia.recibirDia(0);
        screamer = 0;
        textoScreamer = null;
        rojoAplicado = false;
        nivelColoreado = null;
    }

    // ------------------------------------------------------------------ dibujo del screamer

    private static void capas(RegisterGuiLayersEvent event) {
        event.registerAboveAll(Saltalandia.id("screamer"), EfectosCliente::dibujar);
    }

    /** Pantalla negra que tiembla, dos ojos blancos enojados y el texto en rojo. */
    private static void dibujar(GuiGraphics g, DeltaTracker delta) {
        if (screamer <= 0 || textoScreamer == null) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        int ancho = g.guiWidth();
        int alto = g.guiHeight();
        int sx = (int) ((Math.random() - 0.5D) * 10.0D);
        int sy = (int) ((Math.random() - 0.5D) * 10.0D);
        g.fill(0, 0, ancho, alto, screamer % 6 < 2 ? 0xFF000000 : 0xF5080000);

        int cy = (int) (alto * 0.36F) + sy;
        int separacion = Math.max(18, ancho / 9);
        int rx = Math.max(10, ancho / 20);
        int ry = Math.max(12, alto / 9);
        ojo(g, ancho / 2 - separacion + sx, cy, rx, ry, true);
        ojo(g, ancho / 2 + separacion + sx, cy, rx, ry, false);

        float escala = Math.max(2.0F, ancho / 110.0F);
        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(ancho / 2.0F + sx, alto * 0.68F + sy, 0.0F);
        pose.scale(escala, escala, 1.0F);
        int w = mc.font.width(textoScreamer);
        g.drawString(mc.font, textoScreamer, -w / 2, -4, 0xFFD40000, false);
        pose.popPose();
    }

    /** Ojo blanco ovalado, con la esquina de adentro cortada en diagonal (mirada enojada). */
    private static void ojo(GuiGraphics g, int cx, int cy, int rx, int ry, boolean izquierdo) {
        for (int dy = -ry; dy <= ry; dy++) {
            double t = dy / (double) ry;
            int medio = (int) Math.round(rx * Math.sqrt(Math.max(0.0D, 1.0D - t * t)));
            if (medio <= 0) {
                continue;
            }
            int x0 = cx - medio;
            int x1 = cx + medio;
            int corte = (int) Math.round((dy + ry * 0.35D) / 0.6D);
            if (izquierdo) {
                x1 = Math.min(x1, cx + corte);
            } else {
                x0 = Math.max(x0, cx - corte);
            }
            if (x1 > x0) {
                g.fill(x0 - 2, cy + dy, x1 + 2, cy + dy + 1, 0x40FFFFFF);
                g.fill(x0, cy + dy, x1, cy + dy + 1, 0xFFFFFFFF);
            }
        }
    }
}
