package com.saltalandia.cliente;

import com.saltalandia.entidades.BrincoFantasma;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.BlockPos;

/** El Brinco Fantasma brilla: se ve igual de claro en la oscuridad. */
public class RenderFantasma extends RenderHumanoide<BrincoFantasma, ModeloFantasma<BrincoFantasma>> {

    public RenderFantasma(EntityRendererProvider.Context contexto) {
        super(contexto, new ModeloFantasma<>(contexto.bakeLayer(SaltalandiaCliente.CAPA_JUGADOR)), "brinco_fantasma");
    }

    @Override
    protected int getBlockLightLevel(BrincoFantasma entidad, BlockPos pos) {
        return 15;
    }
}
