package com.saltalandia.cliente;

import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.monster.Monster;

/** Modelo de jugador que camina con los brazos estirados, como los zombis (para el Gruñón). */
public class ModeloZombi<T extends Monster> extends HumanoidModel<T> {

    public ModeloZombi(ModelPart raiz) {
        super(raiz);
    }

    @Override
    public void setupAnim(T entidad, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entidad, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, entidad.isAggressive(), this.attackTime, ageInTicks);
    }
}
