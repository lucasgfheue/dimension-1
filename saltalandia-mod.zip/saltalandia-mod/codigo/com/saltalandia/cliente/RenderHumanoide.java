package com.saltalandia.cliente;

import com.mojang.blaze3d.vertex.PoseStack;
import com.saltalandia.Saltalandia;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

/**
 * Renderizador de los personajes con forma de jugador (dibuja tambien lo que tienen en la mano).
 * El modelo de jugador mide 2 bloques: con escala 0.75 los personajes miden 1,5 bloques.
 */
public class RenderHumanoide<T extends Mob, M extends HumanoidModel<T>> extends HumanoidMobRenderer<T, M> {
    public static final float ESCALA = 0.75F;

    private final ResourceLocation textura;

    public RenderHumanoide(EntityRendererProvider.Context contexto, M modelo, String nombre) {
        super(contexto, modelo, 0.5F * ESCALA);
        this.textura = Saltalandia.id("textures/entity/" + nombre + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(T entidad) {
        return this.textura;
    }

    @Override
    protected void scale(T entidad, PoseStack pose, float parcial) {
        pose.scale(ESCALA, ESCALA, ESCALA);
    }
}
