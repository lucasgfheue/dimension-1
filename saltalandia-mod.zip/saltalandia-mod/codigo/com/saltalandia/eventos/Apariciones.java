package com.saltalandia.eventos;

import com.saltalandia.entidades.BrincoSombra;
import com.saltalandia.registro.ModEntidades;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RotationSegment;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/** Cosas que aparecen cerca del jugador: carteles, el Brinco Sombra y las hordas de malos. */
public final class Apariciones {

    private Apariciones() {
    }

    /** Se llama una vez por segundo por cada jugador que esta en Saltalandia. */
    static void cadaSegundo(ServerLevel nivel, ServerPlayer jugador, int dia) {
        if (jugador.isSpectator()) {
            return;
        }
        RandomSource azar = nivel.random;
        // carteles: raros el dia 5 (uno cada ~5 minutos), mas seguido despues
        if (dia >= 5 && dia <= 9 && azar.nextInt(dia >= 8 ? 140 : (dia >= 7 ? 200 : 280)) == 0) {
            ponerCartel(nivel, jugador, dia);
        }
        // Brinco Sombra: muy raro (uno cada ~7 minutos el dia 5); el dia 10 casi siempre esta cerca
        if (dia >= 5 && azar.nextInt(dia >= 10 ? 40 : (dia >= 7 ? 260 : 420)) == 0) {
            traerSombra(nivel, jugador, dia);
        }
        // hordas: dias 8 y 9 (mas seguido de noche)
        if (dia >= 8 && dia <= 9 && azar.nextInt(nivel.isNight() ? 150 : 320) == 0) {
            mandarHorda(nivel, jugador);
        }
    }

    // ------------------------------------------------------------------ carteles

    /** Pone un cartel atras del jugador (para que lo encuentre al darse vuelta), mirando hacia el. */
    static void ponerCartel(ServerLevel nivel, ServerPlayer jugador, int dia) {
        RandomSource azar = nivel.random;
        for (int intento = 0; intento < 12; intento++) {
            double angulo = Math.toRadians(jugador.getYRot() + 180.0F + (azar.nextFloat() - 0.5F) * 140.0F);
            double distancia = 5.0D + azar.nextDouble() * 8.0D;
            BlockPos pos = superficie(nivel, jugador.getX() - Math.sin(angulo) * distancia, jugador.getZ() + Math.cos(angulo) * distancia);
            if (pos == null || Math.abs(pos.getY() - jugador.getY()) > 6.0D) {
                continue;
            }
            float haciaJugador = (float) Math.toDegrees(Math.atan2(-(jugador.getX() - (pos.getX() + 0.5D)), jugador.getZ() - (pos.getZ() + 0.5D)));
            BlockState cartel = Blocks.DARK_OAK_SIGN.defaultBlockState()
                    .setValue(StandingSignBlock.ROTATION, RotationSegment.convertToSegment(haciaJugador));
            if (!nivel.setBlock(pos, cartel, Block.UPDATE_ALL)) {
                continue;
            }
            if (nivel.getBlockEntity(pos) instanceof SignBlockEntity letrero) {
                SignText texto = textoCartel(dia);
                letrero.setText(texto, true);
                letrero.setText(texto, false);
                letrero.setWaxed(true);
            }
            return;
        }
    }

    private static SignText textoCartel(int dia) {
        SignText texto = new SignText();
        if (dia >= 9) {
            texto = texto.setMessage(1, Component.translatable("cartel.saltalandia.un_dia"));
        } else if (dia >= 8) {
            texto = texto.setMessage(1, Component.translatable("cartel.saltalandia.dos_dias"));
        } else {
            texto = texto.setMessage(1, Component.translatable("cartel.saltalandia.vete_1"))
                    .setMessage(2, Component.translatable("cartel.saltalandia.vete_2"));
        }
        return dia >= 7 ? texto.setColor(DyeColor.RED).setHasGlowingText(true) : texto.setColor(DyeColor.WHITE);
    }

    // ------------------------------------------------------------------ Brinco Sombra

    /** Trae al Brinco Sombra a espiar al jugador desde los arboles (fuera del centro de su vista). */
    static void traerSombra(ServerLevel nivel, ServerPlayer jugador, int dia) {
        if (!nivel.getEntitiesOfClass(BrincoSombra.class, jugador.getBoundingBox().inflate(96.0D)).isEmpty()) {
            return;
        }
        RandomSource azar = nivel.random;
        double minimo = dia >= 10 ? 12.0D : 18.0D;
        double maximo = dia >= 10 ? 26.0D : 36.0D;
        Vec3 vista = jugador.getViewVector(1.0F);
        double largoVista = Math.sqrt(vista.x * vista.x + vista.z * vista.z) + 1.0E-6D;
        for (int intento = 0; intento < 30; intento++) {
            double angulo = azar.nextDouble() * Math.PI * 2.0D;
            double distancia = minimo + azar.nextDouble() * (maximo - minimo);
            double dx = Math.cos(angulo) * distancia;
            double dz = Math.sin(angulo) * distancia;
            if ((vista.x * dx + vista.z * dz) / (largoVista * distancia) > 0.9D) {
                continue;   // justo adelante: el jugador lo veria aparecer
            }
            BlockPos pos = lugarEnLosArboles(nivel, jugador.getX() + dx, jugador.getZ() + dz, azar, dia >= 10 && intento > 20);
            if (pos == null) {
                continue;
            }
            BrincoSombra sombra = ModEntidades.BRINCO_SOMBRA.get().create(nivel);
            if (sombra == null) {
                return;
            }
            float giro = (float) Math.toDegrees(Math.atan2(-(jugador.getX() - (pos.getX() + 0.5D)), jugador.getZ() - (pos.getZ() + 0.5D)));
            sombra.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, giro, 0.0F);
            sombra.setYHeadRot(giro);
            sombra.setYBodyRot(giro);
            nivel.addFreshEntity(sombra);
            return;
        }
    }

    /** Un lugar al lado de un tronco o arriba de la copa de un arbol (o cualquiera, si sirveCualquiera). */
    private static BlockPos lugarEnLosArboles(ServerLevel nivel, double x, double z, RandomSource azar, boolean sirveCualquiera) {
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        if (!nivel.hasChunkAt(bx, bz)) {
            return null;
        }
        if (azar.nextInt(10) < 3) {
            BlockPos copa = new BlockPos(bx, nivel.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz), bz);
            if (nivel.getBlockState(copa.below()).is(BlockTags.LEAVES) && nivel.getBlockState(copa).isAir()
                    && nivel.getBlockState(copa.above()).isAir()) {
                return copa;
            }
        }
        BlockPos suelo = superficie(nivel, x, z);
        if (suelo == null) {
            return null;
        }
        if (sirveCualquiera) {
            return suelo;
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = 0; dy <= 3; dy++) {
                    if (nivel.getBlockState(suelo.offset(dx, dy, dz)).is(BlockTags.LOGS)) {
                        return suelo;
                    }
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ hordas

    static void mandarHorda(ServerLevel nivel, ServerPlayer jugador) {
        if (nivel.getEntitiesOfClass(Monster.class, jugador.getBoundingBox().inflate(48.0D)).size() >= 16) {
            return;
        }
        RandomSource azar = nivel.random;
        int cantidad = 5 + azar.nextInt(4);
        int puestos = 0;
        for (int intento = 0; intento < cantidad * 4 && puestos < cantidad; intento++) {
            double angulo = azar.nextDouble() * Math.PI * 2.0D;
            double distancia = 16.0D + azar.nextDouble() * 12.0D;
            BlockPos pos = superficie(nivel, jugador.getX() + Math.cos(angulo) * distancia, jugador.getZ() + Math.sin(angulo) * distancia);
            if (pos == null) {
                continue;
            }
            int r = azar.nextInt(20);
            EntityType<? extends Monster> tipo = r < 12 ? ModEntidades.GRUNON.get() : (r < 19 ? ModEntidades.HUESUDO.get() : ModEntidades.BRINCO_FANTASMA.get());
            Monster malo = tipo.spawn(nivel, pos, MobSpawnType.EVENT);
            if (malo != null) {
                malo.setTarget(jugador);
                puestos++;
            }
        }
        if (puestos > 0) {
            nivel.playSound(null, jugador.getX(), jugador.getY(), jugador.getZ(), SoundEvents.RAID_HORN, SoundSource.HOSTILE, 6.0F, 0.7F);
            jugador.displayClientMessage(Component.translatable("mensaje.saltalandia.horda").withStyle(ChatFormatting.DARK_RED), true);
        }
    }

    // ------------------------------------------------------------------ utilidades

    /** Un lugar en la superficie (no en el agua) donde entra un personaje de 1,5 bloques. */
    static BlockPos superficie(ServerLevel nivel, double x, double z) {
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        if (!nivel.hasChunkAt(bx, bz)) {
            return null;
        }
        BlockPos pos = new BlockPos(bx, nivel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz), bz);
        BlockPos abajo = pos.below();
        if (!nivel.getBlockState(abajo).isFaceSturdy(nivel, abajo, Direction.UP)) {
            return null;
        }
        if (!nivel.getFluidState(pos).isEmpty() || !nivel.getBlockState(pos).canBeReplaced()) {
            return null;
        }
        BlockPos encima = pos.above();
        if (!nivel.getBlockState(encima).getCollisionShape(nivel, encima).isEmpty()) {
            return null;
        }
        return pos;
    }
}
