package com.saltalandia.eventos;

import com.saltalandia.registro.ModBloques;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Cambios del mundo alrededor de los jugadores:
 * dia 7 algunos arboles pierden las hojas, dia 8 todos; dia 9 desaparecen flores, bayas, hongos y cultivos
 * y la comida tirada en el suelo; dia 10 se van los Brincos, los malos y los animales.
 */
public final class CambiosMundo {
    private static final int RADIO_ARBOLES = 44;
    private static final int RADIO_PLANTAS = 40;
    private static final int HOJAS_POR_TICK = 30;
    /** Hojas que faltan quitar (se quitan de a poco para que se vea como se caen). */
    private static final ArrayDeque<BlockPos> COLA_HOJAS = new ArrayDeque<>();
    private static final Set<Long> EN_COLA = new HashSet<>();
    /** Arboles (por la base del tronco) que ya se revisaron en este dia. */
    private static final Set<Long> ARBOLES_VISTOS = new HashSet<>();

    private CambiosMundo() {
    }

    static void reiniciar() {
        COLA_HOJAS.clear();
        EN_COLA.clear();
        ARBOLES_VISTOS.clear();
    }

    static void tick(ServerLevel nivel, List<ServerPlayer> jugadores, int dia) {
        if (dia >= 7) {
            for (ServerPlayer jugador : jugadores) {
                for (int i = 0; i < 4; i++) {
                    buscarArbol(nivel, jugador, dia);
                }
            }
            quitarHojas(nivel);
        }
        if (dia >= 9) {
            for (ServerPlayer jugador : jugadores) {
                for (int i = 0; i < 24; i++) {
                    quitarPlanta(nivel, jugador);
                }
            }
        }
    }

    // ------------------------------------------------------------------ arboles sin hojas

    private static void buscarArbol(ServerLevel nivel, ServerPlayer jugador, int dia) {
        RandomSource azar = nivel.random;
        int x = Mth.floor(jugador.getX()) + azar.nextInt(RADIO_ARBOLES * 2 + 1) - RADIO_ARBOLES;
        int z = Mth.floor(jugador.getZ()) + azar.nextInt(RADIO_ARBOLES * 2 + 1) - RADIO_ARBOLES;
        if (!nivel.hasChunkAt(x, z)) {
            return;
        }
        int arriba = nivel.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
        int suelo = nivel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int y = arriba; y >= suelo; y--) {
            pos.set(x, y, z);
            if (esHojaDeArbol(nivel.getBlockState(pos))) {
                BlockPos base = baseDelTronco(nivel, pos.immutable());
                if (base != null && ARBOLES_VISTOS.add(base.asLong()) && sinHojas(base, dia)) {
                    juntarHojas(nivel, base);
                }
                return;
            }
        }
    }

    /** El dia 7 se secan mas o menos 4 de cada 10 arboles; desde el 8, todos. */
    private static boolean sinHojas(BlockPos base, int dia) {
        if (dia >= 8) {
            return true;
        }
        long h = base.asLong() * 0x9E3779B97F4A7C15L;
        h ^= h >>> 29;
        return Math.floorMod(h, 100L) < 40L;
    }

    private static boolean esHojaDeArbol(BlockState estado) {
        return estado.getBlock() instanceof LeavesBlock && !estado.getValue(LeavesBlock.PERSISTENT);
    }

    /** Sigue la "distancia al tronco" de las hojas hasta llegar al tronco y baja hasta su base. */
    private static BlockPos baseDelTronco(ServerLevel nivel, BlockPos hoja) {
        BlockPos pos = hoja;
        for (int paso = 0; paso < 12; paso++) {
            BlockState estado = nivel.getBlockState(pos);
            if (estado.is(BlockTags.LOGS)) {
                break;
            }
            int distancia = estado.hasProperty(LeavesBlock.DISTANCE) ? estado.getValue(LeavesBlock.DISTANCE) : 7;
            BlockPos siguiente = null;
            for (Direction direccion : Direction.values()) {
                BlockPos vecino = pos.relative(direccion);
                BlockState otro = nivel.getBlockState(vecino);
                if (otro.is(BlockTags.LOGS)) {
                    siguiente = vecino;
                    break;
                }
                if (otro.hasProperty(LeavesBlock.DISTANCE) && otro.getValue(LeavesBlock.DISTANCE) < distancia) {
                    siguiente = vecino;
                    distancia = otro.getValue(LeavesBlock.DISTANCE);
                }
            }
            if (siguiente == null) {
                return null;
            }
            pos = siguiente;
        }
        if (!nivel.getBlockState(pos).is(BlockTags.LOGS)) {
            return null;
        }
        for (int i = 0; i < 40 && nivel.getBlockState(pos.below()).is(BlockTags.LOGS); i++) {
            pos = pos.below();
        }
        return pos;
    }

    /** Recorre tronco y hojas desde la base y pone en la cola las hojas del arbol (de arriba hacia abajo). */
    private static void juntarHojas(ServerLevel nivel, BlockPos base) {
        ArrayDeque<BlockPos> pendientes = new ArrayDeque<>();
        Set<Long> visto = new HashSet<>();
        List<BlockPos> hojas = new ArrayList<>();
        pendientes.add(base);
        visto.add(base.asLong());
        while (!pendientes.isEmpty() && visto.size() < 3000) {
            BlockPos pos = pendientes.poll();
            for (Direction direccion : Direction.values()) {
                BlockPos vecino = pos.relative(direccion);
                if (Math.abs(vecino.getX() - base.getX()) > 7 || Math.abs(vecino.getZ() - base.getZ()) > 7
                        || vecino.getY() < base.getY() || vecino.getY() > base.getY() + 32 || !visto.add(vecino.asLong())) {
                    continue;
                }
                BlockState estado = nivel.getBlockState(vecino);
                if (estado.is(BlockTags.LOGS)) {
                    pendientes.add(vecino);
                } else if (esHojaDeArbol(estado)) {
                    hojas.add(vecino);
                    pendientes.add(vecino);
                }
            }
        }
        hojas.sort(Comparator.comparingInt((BlockPos hoja) -> hoja.getY()).reversed());
        for (BlockPos hoja : hojas) {
            if (EN_COLA.add(hoja.asLong())) {
                COLA_HOJAS.add(hoja);
            }
        }
    }

    private static void quitarHojas(ServerLevel nivel) {
        for (int i = 0; i < HOJAS_POR_TICK && !COLA_HOJAS.isEmpty(); i++) {
            BlockPos pos = COLA_HOJAS.poll();
            EN_COLA.remove(pos.asLong());
            if (!nivel.isLoaded(pos)) {
                continue;
            }
            BlockState estado = nivel.getBlockState(pos);
            if (!esHojaDeArbol(estado)) {
                continue;
            }
            nivel.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            if (nivel.random.nextInt(5) == 0) {
                nivel.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, estado),
                        pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, 3, 0.3D, 0.3D, 0.3D, 0.0D);
            }
        }
    }

    // ------------------------------------------------------------------ sin flores, bayas ni comida

    private static void quitarPlanta(ServerLevel nivel, ServerPlayer jugador) {
        RandomSource azar = nivel.random;
        int x = Mth.floor(jugador.getX()) + azar.nextInt(RADIO_PLANTAS * 2 + 1) - RADIO_PLANTAS;
        int z = Mth.floor(jugador.getZ()) + azar.nextInt(RADIO_PLANTAS * 2 + 1) - RADIO_PLANTAS;
        if (!nivel.hasChunkAt(x, z)) {
            return;
        }
        BlockPos pos = new BlockPos(x, nivel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
        if (esPlanta(nivel.getBlockState(pos))) {
            nivel.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        }
        BlockPos abajo = pos.below();
        BlockState estadoAbajo = nivel.getBlockState(abajo);
        if (estadoAbajo.is(Blocks.MELON) || estadoAbajo.is(Blocks.PUMPKIN)) {
            nivel.setBlock(abajo, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        }
    }

    static boolean esPlanta(BlockState estado) {
        return estado.is(BlockTags.FLOWERS) || estado.is(BlockTags.CROPS)
                || estado.is(ModBloques.FLOR_CAMPANILLA.get()) || estado.is(ModBloques.FLOR_REMOLINO.get())
                || estado.is(ModBloques.HONGO_LUCERO.get()) || estado.is(ModBloques.ARBUSTO_BAYAS.get())
                || estado.is(Blocks.SWEET_BERRY_BUSH) || estado.is(Blocks.BROWN_MUSHROOM) || estado.is(Blocks.RED_MUSHROOM)
                || estado.is(Blocks.MELON_STEM) || estado.is(Blocks.PUMPKIN_STEM)
                || estado.is(Blocks.ATTACHED_MELON_STEM) || estado.is(Blocks.ATTACHED_PUMPKIN_STEM);
    }

    // ------------------------------------------------------------------ dia 9 y 10: limpiar entidades

    /** Dia 9+: la comida tirada desaparece. Dia 10: se van los Brincos, los malos y los animales. */
    static void vaciar(ServerLevel nivel, int dia) {
        List<Entity> fuera = new ArrayList<>();
        for (Entity entidad : nivel.getAllEntities()) {
            if (entidad instanceof ItemEntity cosa && EventosDia.esComida(cosa.getItem())) {
                fuera.add(entidad);
            } else if (dia >= 10 && EventosDia.esHabitante(entidad)) {
                fuera.add(entidad);
            }
        }
        for (Entity entidad : fuera) {
            entidad.discard();
        }
    }
}
