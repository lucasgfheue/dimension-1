package com.saltalandia.eventos;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.saltalandia.Saltalandia;
import com.saltalandia.entidades.Brinco;
import com.saltalandia.red.PaqueteDia;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Los 10 dias de Saltalandia. Cada amanecer (con algun jugador en la dimension) suma un dia y el mundo cambia:
 * <pre>
 *  dia 1-2  todo normal
 *  dia 3    los Brincos ya no regalan nada ni huyen de los malos; los lobos ya no se dejan domesticar
 *  dia 5    los animales no sueltan nada; carteles "GET OUT OF HERE" y el Brinco Sombra (muy raro)
 *  dia 6    no aparecen animales nuevos; los Brincos se "poseen"; los malos son mas rapidos, pegan mas y rompen bloques (lento)
 *  dia 7    screamers rojos ("3 days...", "I said...", "Too late"); algunos arboles pierden las hojas
 *  dia 8    los malos rompen bloques rapido y te ven a traves de las paredes; los Brincos quietos mirandote;
 *           carteles y screamers "2 days..."; ningun arbol tiene hojas; hordas de malos
 *  dia 9    "1 day..."; los malos trepan y ponen bloques; no hay flores, bayas ni comida; agua y pasto rojos
 *  dia 10   desaparecen los malos, los Brincos y los animales: solo quedan el jugador y el Brinco Sombra
 * </pre>
 * Comando: /saltalandia dia (ver el dia) y /saltalandia dia &lt;numero&gt; (cambiarlo, hace falta ser operador).
 */
public final class EventosDia {
    /** Habia jugadores en Saltalandia en el chequeo anterior (si no, el dia que paso no cuenta). */
    private static boolean presente;

    private EventosDia() {
    }

    public static void registrar(IEventBus bus) {
        bus.addListener(EventosDia::tickNivel);
        bus.addListener(EventosDia::alEntrarEntidad);
        bus.addListener(EventosDia::alSoltarCosas);
        bus.addListener(EventosDia::alSoltarExperiencia);
        bus.addListener(EventosDia::alConectarse);
        bus.addListener(EventosDia::alCambiarDimension);
        bus.addListener(EventosDia::alReaparecer);
        bus.addListener(EventosDia::comandos);
        bus.addListener(EventosDia::alIniciarServidor);
    }

    // ------------------------------------------------------------------ reloj de dias

    private static void alIniciarServidor(ServerStartedEvent event) {
        presente = false;
        EstadoDia.diaServidor = DiasSaltalandia.de(event.getServer()).dia();
        CambiosMundo.reiniciar();
    }

    private static void tickNivel(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel nivel) || !nivel.dimension().equals(Saltalandia.DIMENSION)) {
            return;
        }
        DiasSaltalandia datos = DiasSaltalandia.de(nivel.getServer());
        List<ServerPlayer> jugadores = nivel.players();
        long tiempo = nivel.getGameTime();
        if (tiempo % 20L == 0L) {
            avanzar(nivel, datos, !jugadores.isEmpty());
        }
        EstadoDia.diaServidor = datos.dia;
        if (jugadores.isEmpty()) {
            return;
        }
        int dia = datos.dia;
        CambiosMundo.tick(nivel, jugadores, dia);
        if (tiempo % 20L == 0L) {
            for (ServerPlayer jugador : jugadores) {
                Apariciones.cadaSegundo(nivel, jugador, dia);
            }
        }
        if (dia >= 9 && tiempo % 40L == 0L) {
            CambiosMundo.vaciar(nivel, dia);
        }
    }

    /** Cada segundo: si amanecio (y habia jugadores adentro), suma los dias que pasaron. */
    private static void avanzar(ServerLevel nivel, DiasSaltalandia datos, boolean hayJugadores) {
        if (!hayJugadores) {
            presente = false;
            return;
        }
        long indice = Math.floorDiv(nivel.getDayTime(), 24000L);
        if (!datos.iniciado) {
            datos.iniciado = true;
            datos.dia = 1;
            datos.ultimoIndice = indice;
            datos.setDirty();
            presente = true;
            cambioDeDia(nivel, 1);
            return;
        }
        if (!presente) {
            // alguien acaba de llegar: los dias que pasaron mientras no habia nadie no cuentan
            presente = true;
            if (datos.ultimoIndice != indice) {
                datos.ultimoIndice = indice;
                datos.setDirty();
            }
            return;
        }
        if (indice > datos.ultimoIndice) {
            datos.dia += (int) Math.min(indice - datos.ultimoIndice, 30L);
            datos.ultimoIndice = indice;
            datos.setDirty();
            cambioDeDia(nivel, datos.dia);
        } else if (indice < datos.ultimoIndice) {
            datos.ultimoIndice = indice;
            datos.setDirty();
        }
    }

    /** Empieza un dia nuevo: se avisa a los clientes y se muestra el titulo "Dia N". */
    static void cambioDeDia(ServerLevel nivel, int dia) {
        EstadoDia.diaServidor = dia;
        CambiosMundo.reiniciar();
        PacketDistributor.sendToPlayersInDimension(nivel, new PaqueteDia(dia));
        for (ServerPlayer jugador : nivel.players()) {
            jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 25));
            jugador.connection.send(new ClientboundSetTitleTextPacket(textoDia(dia)));
        }
    }

    static Component textoDia(int dia) {
        ChatFormatting color = dia >= 7 ? ChatFormatting.DARK_RED : (dia >= 5 ? ChatFormatting.GRAY : ChatFormatting.GOLD);
        return Component.translatable("titulo.saltalandia.dia", dia).withStyle(color);
    }

    // ------------------------------------------------------------------ el cliente necesita saber el dia

    private static void alConectarse(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer jugador) {
            sincronizar(jugador);
        }
    }

    private static void alCambiarDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer jugador) {
            sincronizar(jugador);
        }
    }

    private static void alReaparecer(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer jugador) {
            sincronizar(jugador);
        }
    }

    private static void sincronizar(ServerPlayer jugador) {
        boolean adentro = jugador.level().dimension().equals(Saltalandia.DIMENSION);
        int dia = adentro ? DiasSaltalandia.de(jugador.server).dia() : 0;
        PacketDistributor.sendToPlayer(jugador, new PaqueteDia(dia));
        if (adentro) {
            jugador.displayClientMessage(textoDia(dia), true);
        }
    }

    // ------------------------------------------------------------------ lo que deja de existir

    /** Desde el dia 6 no aparecen animales nuevos; el 10 tampoco Brincos ni malos; desde el 9 no hay comida tirada. */
    private static void alEntrarEntidad(EntityJoinLevelEvent event) {
        Level nivel = event.getLevel();
        if (nivel.isClientSide() || event.loadedFromDisk() || !nivel.dimension().equals(Saltalandia.DIMENSION)) {
            return;
        }
        int dia = EstadoDia.diaServidor;
        Entity entidad = event.getEntity();
        if (dia >= 10 && esHabitante(entidad)) {
            event.setCanceled(true);
        } else if (dia >= 6 && entidad instanceof Animal) {
            event.setCanceled(true);
        } else if (dia >= 9 && entidad instanceof ItemEntity cosa && esComida(cosa.getItem())) {
            event.setCanceled(true);
        }
    }

    /** Desde el dia 5 los animales no sueltan nada al morir. */
    private static void alSoltarCosas(LivingDropsEvent event) {
        LivingEntity entidad = event.getEntity();
        if (entidad instanceof Animal && EstadoDia.dia(entidad.level()) >= 5) {
            event.setCanceled(true);
        }
    }

    private static void alSoltarExperiencia(LivingExperienceDropEvent event) {
        LivingEntity entidad = event.getEntity();
        if (entidad instanceof Animal && EstadoDia.dia(entidad.level()) >= 5) {
            event.setDroppedExperience(0);
        }
    }

    /** Brincos y malos (los que se van el dia 10). El Brinco Sombra no cuenta. */
    static boolean esHabitante(Entity entidad) {
        return entidad instanceof Brinco || entidad instanceof Enemy || entidad instanceof Animal;
    }

    static boolean esComida(ItemStack cosa) {
        return cosa.has(DataComponents.FOOD);
    }

    // ------------------------------------------------------------------ comando /saltalandia dia

    private static void comandos(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("saltalandia")
                .then(Commands.literal("dia")
                        .executes(contexto -> {
                            int dia = DiasSaltalandia.de(contexto.getSource().getServer()).dia();
                            contexto.getSource().sendSuccess(() -> Component.translatable("comando.saltalandia.dia", dia), false);
                            return dia;
                        })
                        .then(Commands.argument("numero", IntegerArgumentType.integer(1, 99))
                                .requires(fuente -> fuente.hasPermission(2))
                                .executes(contexto -> ponerDia(contexto.getSource(), IntegerArgumentType.getInteger(contexto, "numero"))))));
    }

    private static int ponerDia(CommandSourceStack fuente, int dia) {
        ServerLevel nivel = fuente.getServer().getLevel(Saltalandia.DIMENSION);
        DiasSaltalandia datos = DiasSaltalandia.de(fuente.getServer());
        datos.dia = dia;
        datos.iniciado = true;
        if (nivel != null) {
            datos.ultimoIndice = Math.floorDiv(nivel.getDayTime(), 24000L);
            cambioDeDia(nivel, dia);
        }
        datos.setDirty();
        EstadoDia.diaServidor = dia;
        fuente.sendSuccess(() -> Component.translatable("comando.saltalandia.dia_puesto", dia), true);
        return dia;
    }
}
