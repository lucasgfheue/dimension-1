package com.saltalandia.eventos;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Contador de dias de Saltalandia, guardado con el mundo (archivo data/saltalandia_dias.dat).
 * El dia 1 empieza la primera vez que alguien entra a Saltalandia y cada amanecer suma un dia,
 * pero solo cuenta los dias que pasan mientras hay algun jugador adentro de la dimension
 * (si te vas al mundo normal, el contador se queda quieto hasta que vuelvas).
 */
public final class DiasSaltalandia extends SavedData {
    private static final String ARCHIVO = "saltalandia_dias";

    int dia = 1;
    /** Numero de dia del reloj (tiempo / 24000) que se vio por ultima vez con jugadores adentro. */
    long ultimoIndice;
    boolean iniciado;

    private DiasSaltalandia() {
    }

    public static DiasSaltalandia de(MinecraftServer servidor) {
        return servidor.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(DiasSaltalandia::new, DiasSaltalandia::cargar, null), ARCHIVO);
    }

    public int dia() {
        return this.dia;
    }

    private static DiasSaltalandia cargar(CompoundTag tag, HolderLookup.Provider registros) {
        DiasSaltalandia datos = new DiasSaltalandia();
        datos.dia = Math.max(1, tag.getInt("Dia"));
        datos.ultimoIndice = tag.getLong("UltimoIndice");
        datos.iniciado = tag.getBoolean("Iniciado");
        return datos;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registros) {
        tag.putInt("Dia", this.dia);
        tag.putLong("UltimoIndice", this.ultimoIndice);
        tag.putBoolean("Iniciado", this.iniciado);
        return tag;
    }
}
