package com.saltalandia.eventos;

import com.saltalandia.Saltalandia;
import net.minecraft.world.level.Level;

/**
 * En que dia de Saltalandia estamos. Lo usan los personajes, los bloques y el cliente.
 * <ul>
 *   <li>En el servidor el dia sale de {@link DiasSaltalandia} (se guarda con el mundo).</li>
 *   <li>En el cliente es el dia que le mando el servidor con {@link com.saltalandia.red.PaqueteDia}.</li>
 * </ul>
 * Fuera de Saltalandia siempre devuelve 0: ningun efecto de los dias pasa en otras dimensiones.
 */
public final class EstadoDia {
    /** Dia actual en el servidor (lo actualiza {@link EventosDia} cada tick). */
    static volatile int diaServidor = 1;
    /** Dia que el servidor le mando a este cliente (0 = fuera de Saltalandia o sin datos todavia). */
    private static volatile int diaCliente = 0;
    /** El cliente acaba de pasar del dia 9 al 10 (para el ultimo susto). */
    private static volatile boolean finalPendiente = false;

    private EstadoDia() {
    }

    /** Dia de Saltalandia para este nivel (0 si el nivel no es Saltalandia). */
    public static int dia(Level nivel) {
        if (nivel == null || !nivel.dimension().equals(Saltalandia.DIMENSION)) {
            return 0;
        }
        return nivel.isClientSide() ? Math.max(diaCliente, 1) : diaServidor;
    }

    /** Dia que conoce el cliente (0 si esta fuera de Saltalandia). */
    public static int diaCliente() {
        return diaCliente;
    }

    /** Lo llama el paquete del servidor (en el hilo principal del cliente). */
    public static void recibirDia(int nuevo) {
        int viejo = diaCliente;
        diaCliente = nuevo;
        if (viejo == 9 && nuevo == 10) {
            finalPendiente = true;
        }
    }

    /** Devuelve true una sola vez cuando el cliente paso del dia 9 al 10. */
    public static boolean tomarFinalPendiente() {
        if (finalPendiente) {
            finalPendiente = false;
            return true;
        }
        return false;
    }
}
