package com.saltalandia;

import com.saltalandia.bloques.BloqueRebote;
import com.saltalandia.entidades.Brinco;
import com.saltalandia.entidades.BrincoFantasma;
import com.saltalandia.entidades.Grunon;
import com.saltalandia.entidades.Huesudo;
import com.saltalandia.mundo.NubeFeature;
import com.saltalandia.registro.ModBloques;
import com.saltalandia.registro.ModEntidades;
import com.saltalandia.registro.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Saltalandia: una dimension de plataformas con colinas, lagos, arboles de colores,
 * bloques rebote, Pueblos Brinco y Fortines Gruñón.
 */
@Mod(Saltalandia.MODID)
public class Saltalandia {
    public static final String MODID = "saltalandia";

    /** La dimension (definida por JSON en datos/data/saltalandia/dimension/saltalandia.json). */
    public static final ResourceKey<Level> DIMENSION = ResourceKey.create(Registries.DIMENSION, id("saltalandia"));

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(Registries.FEATURE, MODID);

    public static final DeferredHolder<Feature<?>, NubeFeature> NUBE = FEATURES.register("nube",
            () -> new NubeFeature(NoneFeatureConfiguration.CODEC));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> PESTANA = TABS.register("saltalandia",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.saltalandia"))
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .icon(() -> ModItems.BLOQUE_REBOTE.get().getDefaultInstance())
                    .displayItems((parametros, salida) -> {
                        for (DeferredHolder<Item, ? extends Item> item : ModItems.ITEMS.getEntries()) {
                            salida.accept(item.get());
                        }
                    })
                    .build());

    public Saltalandia(IEventBus modEventBus, ModContainer modContainer) {
        ModBloques.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModEntidades.ENTIDADES.register(modEventBus);
        TABS.register(modEventBus);
        FEATURES.register(modEventBus);

        modEventBus.addListener(Saltalandia::atributos);
        modEventBus.addListener(Saltalandia::lugaresDeAparicion);
        NeoForge.EVENT_BUS.addListener(Saltalandia::alCaer);
    }

    public static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(MODID, ruta);
    }

    /** Vida, velocidad, ataque... de cada personaje. */
    private static void atributos(EntityAttributeCreationEvent event) {
        event.put(ModEntidades.BRINCO.get(), Brinco.crearAtributos().build());
        event.put(ModEntidades.GRUNON.get(), Grunon.crearAtributos().build());
        event.put(ModEntidades.HUESUDO.get(), Huesudo.crearAtributos().build());
        event.put(ModEntidades.BRINCO_FANTASMA.get(), BrincoFantasma.crearAtributos().build());
    }

    /**
     * Donde pueden aparecer solos los malos (aunque sea de dia: en Saltalandia siempre es de dia).
     * El Brinco no aparece solo: vive unicamente en los Pueblos Brinco.
     */
    private static void lugaresDeAparicion(RegisterSpawnPlacementsEvent event) {
        event.register(ModEntidades.GRUNON.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules, RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(ModEntidades.HUESUDO.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules, RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(ModEntidades.BRINCO_FANTASMA.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkAnyLightMonsterSpawnRules, RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    /** Si caes despues de rebotar en un Bloque Rebote, no recibes dano. */
    private static void alCaer(LivingFallEvent event) {
        CompoundTag datos = event.getEntity().getPersistentData();
        if (datos.contains(BloqueRebote.ETIQUETA_REBOTE)) {
            long cuando = datos.getLong(BloqueRebote.ETIQUETA_REBOTE);
            datos.remove(BloqueRebote.ETIQUETA_REBOTE);
            if (event.getEntity().level().getGameTime() - cuando < 400L) {
                event.setCanceled(true);
            }
        }
    }
}
