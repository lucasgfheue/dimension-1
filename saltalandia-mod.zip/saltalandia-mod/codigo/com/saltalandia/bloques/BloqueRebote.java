package com.saltalandia.bloques;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Bloque Rebote: un trampolin (6/16 de bloque de alto, con patas, borde acolchado y lona).
 * Al pisarlo te lanza hacia arriba (unos 27 bloques). Si vas agachado (shift) no rebota.
 * Despues del salto no recibes dano al caer.
 */
public class BloqueRebote extends Block {
    /** Velocidad vertical del lanzamiento (2.4 ~ 27 bloques de altura). */
    public static final double IMPULSO = 2.4D;
    /** Marca que se guarda en la entidad para no hacerle dano al caer despues del rebote. */
    public static final String ETIQUETA_REBOTE = "saltalandia_rebote";

    /** Forma del trampolin: 6/16 de bloque de alto (se sube caminando, como una alfombra alta). */
    private static final VoxelShape FORMA = Block.box(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D);

    public BloqueRebote(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return FORMA;
    }

    @Override
    public void fallOn(Level level, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        if (entity.isShiftKeyDown()) {
            super.fallOn(level, state, pos, entity, fallDistance);
        } else {
            entity.causeFallDamage(fallDistance, 0.0F, level.damageSources().fall());
        }
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (!entity.isShiftKeyDown()) {
            Vec3 movimiento = entity.getDeltaMovement();
            if (movimiento.y < IMPULSO * 0.5D) {
                entity.setDeltaMovement(movimiento.x, IMPULSO, movimiento.z);
                entity.resetFallDistance();
                if (!level.isClientSide) {
                    entity.getPersistentData().putLong(ETIQUETA_REBOTE, level.getGameTime());
                }
                Player jugador = entity instanceof Player p ? p : null;
                level.playSound(jugador, pos, SoundEvents.SLIME_JUMP, SoundSource.BLOCKS, 1.0F, 1.5F);
                if (level.isClientSide) {
                    for (int i = 0; i < 10; i++) {
                        level.addParticle(ParticleTypes.CLOUD,
                                pos.getX() + level.random.nextDouble(), pos.getY() + 0.4D, pos.getZ() + level.random.nextDouble(),
                                0.0D, 0.12D, 0.0D);
                    }
                }
            }
        }
        super.stepOn(level, pos, state, entity);
    }
}
