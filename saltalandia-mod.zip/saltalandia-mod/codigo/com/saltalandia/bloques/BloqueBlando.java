package com.saltalandia.bloques;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Bloque "blando" que amortigua las caidas.
 * multiplicadorCaida = 0.2 -> recibes el 20% del dano; 0.0 -> nada de dano.
 */
public class BloqueBlando extends Block {
    private final float multiplicadorCaida;

    public BloqueBlando(float multiplicadorCaida, BlockBehaviour.Properties properties) {
        super(properties);
        this.multiplicadorCaida = multiplicadorCaida;
    }

    @Override
    public void fallOn(Level level, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        entity.causeFallDamage(fallDistance, this.multiplicadorCaida, level.damageSources().fall());
    }
}
