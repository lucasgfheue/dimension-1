package com.saltalandia.bloques;

import com.saltalandia.Saltalandia;
import com.saltalandia.registro.ModBloques;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Portal Saltarin: haz clic derecho sobre el para viajar.
 * Desde cualquier dimension te lleva a Saltalandia; desde Saltalandia te devuelve al mundo normal.
 * En el destino busca un portal cercano y, si no hay, crea uno nuevo para que puedas volver.
 */
public class PortalSaltarin extends Block {
    private static final int RADIO_BUSQUEDA = 6;

    public PortalSaltarin(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (level instanceof ServerLevel nivel && player instanceof ServerPlayer jugador) {
            viajar(nivel, pos, jugador);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        for (int i = 0; i < 3; i++) {
            double x = pos.getX() + random.nextDouble();
            double y = pos.getY() + 1.0D + random.nextDouble() * 0.5D;
            double z = pos.getZ() + random.nextDouble();
            level.addParticle(ParticleTypes.PORTAL, x, y, z, (random.nextDouble() - 0.5D) * 0.5D, -random.nextDouble() * 0.5D, (random.nextDouble() - 0.5D) * 0.5D);
        }
    }

    private static void viajar(ServerLevel origen, BlockPos portalOrigen, ServerPlayer jugador) {
        MinecraftServer server = origen.getServer();
        boolean volviendo = origen.dimension().equals(Saltalandia.DIMENSION);
        ServerLevel destino = volviendo ? server.overworld() : server.getLevel(Saltalandia.DIMENSION);
        if (destino == null) {
            jugador.displayClientMessage(Component.translatable("mensaje.saltalandia.sin_dimension"), true);
            return;
        }

        BlockPos llegada = buscarPortal(destino, portalOrigen.getX(), portalOrigen.getZ());
        if (llegada == null) {
            llegada = crearPortal(destino, portalOrigen.getX(), portalOrigen.getZ());
        }

        Vec3 posicion = new Vec3(llegada.getX() + 0.5D, llegada.getY() + 1.0D, llegada.getZ() + 0.5D);
        jugador.changeDimension(new DimensionTransition(destino, posicion, Vec3.ZERO,
                jugador.getYRot(), jugador.getXRot(), DimensionTransition.PLACE_PORTAL_TICKET));
        destino.playSound(null, llegada, SoundEvents.CHORUS_FRUIT_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        jugador.displayClientMessage(Component.translatable(
                volviendo ? "mensaje.saltalandia.regreso" : "mensaje.saltalandia.llegada"), true);
    }

    /** Busca el Portal Saltarin mas cercano a (x, z) en el destino (null si no hay). */
    private static BlockPos buscarPortal(ServerLevel nivel, int x, int z) {
        Block portal = ModBloques.PORTAL_SALTARIN.get();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        BlockPos mejor = null;
        double mejorDistancia = Double.MAX_VALUE;
        for (int dx = -RADIO_BUSQUEDA; dx <= RADIO_BUSQUEDA; dx++) {
            for (int dz = -RADIO_BUSQUEDA; dz <= RADIO_BUSQUEDA; dz++) {
                for (int y = nivel.getMinBuildHeight(); y < nivel.getMaxBuildHeight(); y++) {
                    cursor.set(x + dx, y, z + dz);
                    if (nivel.getBlockState(cursor).is(portal)) {
                        double distancia = dx * dx + dz * dz;
                        if (distancia < mejorDistancia) {
                            mejorDistancia = distancia;
                            mejor = cursor.immutable();
                        }
                    }
                }
            }
        }
        return mejor;
    }

    /** Crea un portal sobre el suelo en (x, z), con una plataforma de nubes si hace falta. */
    private static BlockPos crearPortal(ServerLevel nivel, int x, int z) {
        int min = nivel.getMinBuildHeight();
        int max = nivel.getMaxBuildHeight();
        int y = nivel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y <= min + 1) {
            y = 100; // columna vacia: lo ponemos en el aire sobre una nube
        }
        y = Mth.clamp(y, min + 1, max - 4);
        BlockPos posPortal = new BlockPos(x, y, z);

        BlockPos abajo = posPortal.below();
        if (!nivel.getBlockState(abajo).isFaceSturdy(nivel, abajo, Direction.UP)) {
            BlockState nube = ModBloques.NUBE_SOLIDA.get().defaultBlockState();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos p = abajo.offset(dx, 0, dz);
                    BlockState actual = nivel.getBlockState(p);
                    if (actual.isAir() || actual.is(BlockTags.REPLACEABLE) || !actual.getFluidState().isEmpty()) {
                        nivel.setBlockAndUpdate(p, nube);
                    }
                }
            }
        }

        nivel.setBlockAndUpdate(posPortal, ModBloques.PORTAL_SALTARIN.get().defaultBlockState());

        // Espacio libre para aparecer encima del portal
        for (int i = 1; i <= 2; i++) {
            BlockPos p = posPortal.above(i);
            BlockState actual = nivel.getBlockState(p);
            if (!actual.isAir() && (actual.is(BlockTags.REPLACEABLE) || actual.is(BlockTags.LEAVES))) {
                nivel.removeBlock(p, false);
            }
        }
        return posPortal;
    }
}
