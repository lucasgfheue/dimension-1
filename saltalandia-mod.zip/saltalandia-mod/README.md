# Saltalandia (Minecraft 1.21.1 · NeoForge)

Una dimensión original de plataformas: colinas y lagos con **tres biomas**, **cinco tipos de árboles**,
**trampolines que te lanzan por el aire**, **nubes sólidas**, **cuatro minerales nuevos**, **siete comidas**,
**cuatro personajes con forma de jugador** (skin de tortuga y sus versiones zombi, esqueleto y fantasma),
**cuatro animales nuevos**, **Pueblos Brinco** habitados, **Fortines Gruñón** custodiados, la **Espada Huesuda**,
**día y noche**, **cuevas** y **los 10 días de Saltalandia**: cada día que pasas ahí, la dimensión se pone más rara...

## Cómo compilarlo en GitHub

### La más fácil: subir el .zip tal cual

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. *Add file → Upload files* y sube `saltalandia-mod.zip` **sin descomprimir** → *Commit changes*.
3. *Add file → Create new file*, en el nombre escribe `.github/workflows/build.yml`, pega el contenido de ese
   mismo archivo (está dentro del .zip) → *Commit changes*.
4. En **Actions** se compila solo: el workflow descomprime el .zip y compila. Al terminar en verde,
   descarga el artefacto **saltalandia-mod** (adentro está `saltalandia-1.0.0.jar`).

### Opción A: desde la web, con los archivos descomprimidos

GitHub deja subir **hasta 100 archivos por vez**, así que el proyecto viene dividido en carpetas
y se sube en **4 tandas**. Respeta el orden: la carpeta `.github` (la que dispara la compilación)
va en la última tanda, así la primera compilación ya tiene todo.

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. Descomprime el .zip en tu PC.
3. En el repositorio: *Add file → Upload files* (o el enlace *uploading an existing file* si está vacío).
   - **Tanda 1:** arrastra la carpeta `datos` → *Commit changes*.
   - **Tanda 2:** arrastra la carpeta `modelos` → *Commit changes*.
   - **Tanda 3:** arrastra la carpeta `texturas` → *Commit changes*.
   - **Tanda 4:** arrastra todo lo demás: las carpetas `.github`, `codigo`, `gradle`, `plantillas`
     y los archivos `build.gradle`, `settings.gradle`, `gradle.properties`, `gradlew`,
     `gradlew.bat`, `.gitignore` y `README.md` → *Commit changes*.

   Arrastra las **carpetas enteras** (no su contenido suelto) para que se mantenga la estructura.
   En Mac la carpeta `.github` está oculta: en el Finder pulsa `Cmd + Shift + .` para verla.
4. Ve a la pestaña **Actions**: se compila solo (tarda unos 5–10 minutos).
5. Cuando termine en verde, entra a esa ejecución y descarga el artefacto **saltalandia-mod**.
   Adentro está `saltalandia-1.0.0.jar`.

### Opción B: con GitHub Desktop o git

Clona el repositorio vacío, copia **todo** el contenido del .zip adentro y haz *commit* + *push* de una vez.
La compilación arranca sola igual que arriba.

## Cómo instalarlo

1. Instala **NeoForge 21.1.x** para **Minecraft 1.21.1**.
2. Copia `saltalandia-1.0.0.jar` en la carpeta `mods` de tu `.minecraft`.

## Cómo llegar

**Portal Saltarín**: fabrícalo, colócalo y haz **clic derecho** sobre él. En Saltalandia aparece otro
portal (sobre una plataforma de nubes si hace falta) para volver con clic derecho.

```
Oro      Pluma    Oro
Pluma    Diamante Pluma
Oro      Pluma    Oro
```

## El mundo

- **Biomas:** *Praderas Saltarinas* (colinas abiertas), *Bosque Pompón* (bosque denso) y
  *Jardín de Algodón* (árboles rosados y muchas flores). No hay islas flotantes: todo es terreno firme,
  con lagos y nubes sólidas en el cielo.
- **Día y noche:** Saltalandia usa el mismo reloj que el mundo normal. Los malos aparecen de noche
  (o en lugares oscuros, como las cuevas). Si dormís en una cama de Saltalandia, se hace de día.
- **Cuevas y cañones:** hay cuevas y cañones como en el mundo normal, que atraviesan la Piedra Pastel y dejan
  ver los minerales. Las cuevas debajo de las colinas quedan secas; las que pasan debajo de los lagos pueden tener agua,
  y al fondo de todo hay lava.
- **Árboles:**
  - Pompón (copa redonda turquesa) → **Fruta Saltarina**
  - Limonero (chico, hojas amarillo verdoso) → **Limón Burbuja**
  - Pino Menta (cónico, en el bosque) → **Bayas Menta**
  - Algodón (ramas abiertas y copas rosadas) → **Algodón de Azúcar**
  - Pompón Gigante (tronco de 2×2, en el bosque)
- **Plantas:** Flor Campanilla, Flor Remolino, Hongo Lucero (da luz) y Arbusto de Bayas Menta,
  además de flores y pasto normales.
- **Minerales** (en la Piedra Pastel):
  - Mena de Gema Saltarina (pico de piedra)
  - Mena de Azúcar Cristal
  - Mena de Ámbar Miel (pico de piedra)
  - Mena de Lunarita (pico de hierro, brilla un poco)

## Personajes

Tienen forma de jugador con la skin de tortuga y miden **1,5 bloques** de alto.
Los malos te ven desde mucho más lejos que los monstruos normales (48 bloques; el fantasma 64).

| Personaje | Tipo | Qué hace |
|---|---|---|
| **Brinco** | bueno | La tortuga con la piel en un verde más claro. Vive **solo en los Pueblos Brinco** (no aparece suelto por el mundo). Clic derecho: te regala una comida (una vez cada 5 minutos). Huye de los malos. |
| **Gruñón** | malo | Versión **zombi** de la tortuga: camina con los brazos estirados, pega fuerte, tiene armadura y casi no retrocede. Suelta Goma Agria y a veces gemas, azúcar o ámbar. |
| **Huesudo** | malo | Versión **esqueleto** de la tortuga. Pelea con la **Espada Huesuda** y cada golpe te deja lento unos segundos. Suelta huesos y tiene un **5%** de probabilidad de soltar su espada (si lo mata un jugador). |
| **Brinco Sombra** | ??? | Un Brinco **todo negro con ojos blancos** que brillan en la oscuridad. Aparece desde el **día 5** de Saltalandia, muy pocas veces, y te espía quieto desde los árboles. Si lo miras o te acercas, desaparece. No ataca ni hace ruido. |
| **Brinco Fantasma** | malo (raro) | Versión **fantasma** del Brinco: translúcido, con ojos y dientes blancos, brilla en la oscuridad. Vuela y **atraviesa bloques** para atacarte, y **te ve a través de los bloques**. Aparece **mucho menos** que los otros malos y siempre de a uno. A veces suelta una Lunarita. |

Los malos aparecen de noche y no se queman con el sol.
Hay huevos de todos en la pestaña creativa. Con los días de Saltalandia todos van cambiando (mira la tabla de los 10 días).

## Animales

Cada uno vive en el bioma que le queda. Tienen la forma de un toro, una llama, un lobo y una gallina,
y funcionan como sus parientes del mundo normal.

| Animal | Dónde vive | Qué hace |
|---|---|---|
| **Toro Caramelo** | Praderas Saltarinas | Toro color caramelo con cuernos y argolla dorada. Se cría con trigo y suelta carne y cuero. Es un toro: no da leche. |
| **Llama Algodón** | Jardín de Algodón | Llama esponjosa de algodón de azúcar rosado. Se doma montándola, lleva cofre, se le pone alfombra y escupe. Una vez domada, se cría con fardos de heno. |
| **Lobo Menta** | Bosque Pompón | Lobo verde menta. Se domestica con huesos: te sigue, se sienta, usa collar y armadura de lobo y te defiende de los enemigos. |
| **Gallina Confite** | Praderas y Jardín | Gallina blanca de merengue con confites de colores y cresta rosada. Pone huevos (sirven para el Pastel de Bayas) y se cría con semillas. |

Hay huevos de los cuatro en la pestaña creativa.

## Los 10 días de Saltalandia

Cada amanecer suma un día, pero **solo cuentan los días que pasan mientras estás en Saltalandia**
(si te vas al mundo normal, el contador se queda quieto). Al empezar cada día aparece el título "Día N".
Los cambios se acumulan: el día 8 sigue pasando todo lo de los días anteriores.

| Día | Qué pasa |
|---|---|
| **1 y 2** | Todo normal. |
| **3 y 4** | Los Brincos ya no te regalan nada y ya no huyen de los malos. Los Lobos Menta ya no se dejan domesticar. |
| **5** | Los animales ya no sueltan nada (ni las gallinas ponen huevos). Aparecen, muy de vez en cuando, carteles con **GET OUT OF HERE** alrededor tuyo. Aparece el **Brinco Sombra**: un Brinco todo negro con ojos blancos que te espía desde los árboles (al lado de un tronco o arriba de una copa). Es muy raro; si lo miras o te acercas, desaparece. |
| **6** | Ya no aparecen animales nuevos. Los Brincos a veces se "poseen": se quedan quietos y la cabeza se les retuerce. Los malos son más rápidos, pegan más, te ven desde más lejos y rompen bloques para llegar hasta ti (muy despacio: de 5 a 20 segundos por bloque). |
| **7** | Screamers en la pantalla: fondo negro, ojos blancos y **3 days...**, **I said...** o **Too late** en rojo. Algunos árboles pierden las hojas. Los carteles salen en rojo. |
| **8** | Los malos están furiosos: rompen bloques en 1 o 2 segundos, te ven a través de las paredes y desde el doble de distancia. Los Brincos no se mueven y te miran fijo. Carteles y screamers dicen **2 days...**. Ningún árbol tiene hojas. Llegan **hordas** de malos a buscarte. |
| **9** | Carteles y screamers: **1 day...**. Si estás muy alto, los malos trepan las paredes y ponen bloques para alcanzarte. Desaparecen las flores, las bayas, los hongos, los cultivos y la comida tirada. **El agua y el pasto se vuelven rojos.** |
| **10** | Desaparecen los malos, los Brincos y los animales. Solo quedan tú... y el Brinco Sombra, que aparece mucho más seguido. |

Las hojas, las flores y la comida que se fueron no vuelven. Los malos rompen y ponen bloques solo si la regla
`mobGriefing` está activada (lo está por defecto).

**Comando para probarlo** (en un mundo con trucos activados):
- `/saltalandia dia` → muestra en qué día estás.
- `/saltalandia dia 7` → salta al día 7 (sirve cualquier número del 1 al 99; para volver a empezar, `/saltalandia dia 1`).

## Estructuras

- **Pueblo Brinco** (en praderas y jardines): 4 casas de colores con cama, mesa de crafteo y cofre,
  plaza con fuente, faroles de Lunarita, huertas de bayas, dos trampolines para jugar y sus habitantes:
  8 Brincos.
- **Fortín Gruñón** (en bosques y praderas): murallas rotas, una torre con un generador de Gruñones
  y 3 cofres con botín (gemas, lunarita, oro, hierro y a veces diamantes). Lo cuidan Gruñones y un Huesudo.

## Bloques especiales

- **Trampolín Rebote** (el Bloque Rebote): tiene forma de trampolín, con patas, borde acolchado y lona con
  una estrella. Al pisarlo te lanza unos 27 bloques hacia arriba y durante 20 segundos no recibes daño
  al caer. Agáchate (Shift) si no quieres rebotar. También aparecen sueltos sobre el césped.
- **Nube Sólida**: se puede caminar encima y no hace daño por caída.
- **Césped Saltarín**: amortigua las caídas (solo recibes el 20% del daño). Toma el color de pasto de cada bioma.
- **Lámpara de Lunarita**: luz máxima.

## Espada Huesuda

Hoja de hueso, guarda de caparazón y una gema en el mango. Pega como una espada de hierro, se encanta
como cualquier espada, se repara con lingotes de hierro y **deja lento** durante 3 segundos a lo que golpea.
No tiene receta: solo la suelta el Huesudo (5%).

## Comidas

| Comida | Efecto |
|---|---|
| Fruta Saltarina | Salto II (45 s) + caída lenta (15 s) |
| Limón Burbuja | Velocidad (30 s) |
| Algodón de Azúcar | Se come rápido, regeneración (5 s) |
| Bayas Menta | Se comen rápido; también se plantan como arbusto |
| Caramelo de Miel | Absorción (1 min) |
| Pastel de Bayas | Llena mucho (8) |
| Brocheta de Frutas | Llena muchísimo (10) + salto y velocidad (30 s) |

## Recetas

| Resultado | Ingredientes |
|---|---|
| 2 Trampolines Rebote | Gema Saltarina + Nube Sólida (sin forma) |
| 2 Trampolines Rebote | Gema Saltarina + Goma Agria (sin forma) |
| 1 Nube Sólida | 4 Algodones de Azúcar (en cuadrado 2×2) |
| 4 Ladrillos Pastel | 4 Piedras Pastel (en cuadrado 2×2) |
| 2 Lámparas de Lunarita | 4 Lunaritas en cruz alrededor de 1 Vidrio |
| 4 Tablones | 1 Tronco Pompón o 1 Tronco Canela |
| 3 Azúcar | 1 Azúcar Cristal |
| 2 Caramelos de Miel | Ámbar Miel + Azúcar Cristal |
| 1 Pastel de Bayas | 3 Bayas Menta + Azúcar Cristal + Huevo + Trigo |
| 1 Brocheta de Frutas | Palo + Fruta Saltarina + Limón Burbuja + Bayas Menta |

Todo está también en la pestaña creativa **Saltalandia**.

## Estructura del proyecto

- `codigo/` — código Java (bloques, portal, nubes, personajes, sus modelos y la espada).
  Los 10 días están en `codigo/com/saltalandia/eventos/` (el contador, los carteles, las hordas, los árboles
  sin hojas...), la inteligencia nueva de los malos en `entidades/ia/` y los screamers y el agua roja en
  `cliente/EfectosCliente.java`.
- `datos/` — la dimensión, biomas, terreno, árboles, estructuras (`.nbt`), recetas, botín y etiquetas.
- `modelos/` — estados de bloque, modelos de bloques e ítems y textos.
  Los textos están en `lang/en_us.json` (el idioma de respaldo de Minecraft),
  así se ven en español con cualquier idioma del juego. Ahí también están los textos de los carteles y
  los screamers (`cartel.saltalandia...` y `screamer.saltalandia...`), por si quieres cambiarlos.
- `texturas/` — todas las texturas (bloques, ítems y personajes; los personajes salen de la skin de tortuga).
- `plantillas/` — la plantilla de `neoforge.mods.toml`.
